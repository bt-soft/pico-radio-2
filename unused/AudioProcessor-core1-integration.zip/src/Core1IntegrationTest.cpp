#include <vector>

#include "AudioProcessor.h"
#include "AudioProcessorCore1Integration.h"
#include "Core1FftProcessor.h"
#include "PicoMemoryInfo.h"
#include "defines.h"

/**
 * @brief Átfogó integritás teszt a Core1 delegációs rendszerhez
 * Ellenőrzi hogy az összes komponens együttműködik és működik-e
 */
void runCore1IntegrationTest() {
    DEBUG("\n");
    DEBUG("================================================================\n");
    DEBUG("             CORE1 DELEGÁCIÓS RENDSZER INTEGRITÁS TESZT         \n");
    DEBUG("================================================================\n");

    MemoryStatus_t initialMem = getMemoryStatus();
    DEBUG("Kezdeti memória állapot:\n");
    DEBUG("  Használt heap: %lu bytes (%.2f KB)\n", initialMem.usedHeap, initialMem.usedHeap / 1024.0f);
    DEBUG("  Szabad heap: %lu bytes (%.2f KB)\n", initialMem.freeHeap, initialMem.freeHeap / 1024.0f);
    DEBUG("\n");

    // Teszt adatok létrehozása
    const uint16_t testSize = 256;
    std::vector<float> testInput(testSize);
    std::vector<float> testOutput(testSize);

    // Teszt szinusz jel generálása
    for (uint16_t i = 0; i < testSize; i++) {
        testInput[i] = sin(2.0f * PI * 5.0f * i / testSize) + 0.5f * sin(2.0f * PI * 15.0f * i / testSize);
    }

    DEBUG("=== TESZT 1: Core1FftProcessor alapfunkciók ===\n");

    // Core1 FFT processor létrehozása
    Core1FftProcessor processor;
    if (!processor.initialize()) {
        DEBUG("HIBA: Core1FftProcessor inicializálás sikertelen!\n");
        return;
    }
    DEBUG("✓ Core1FftProcessor inicializálva\n");

    // Alap FFT teszt (szinkron)
    uint32_t startTime = millis();
    bool success = processor.processFFTSync(testInput.data(), testSize, testOutput.data(), true);
    uint32_t duration = millis() - startTime;

    if (success) {
        DEBUG("✓ Core1 FFT feldolgozás sikeres\n");
        DEBUG("  Feldolgozási idő: %lu ms\n", duration);
        // A ProcessorStats-ból szerezzük a teljesítmény adatokat
        auto stats = processor.getStats();
        DEBUG("  Összes parancs: %lu\n", stats.totalCommands);
        DEBUG("  Sikeres arány: %.1f%%\n", stats.totalCommands > 0 ? (float)stats.successfulCommands / stats.totalCommands * 100.0f : 0.0f);
    } else {
        DEBUG("✗ Core1 FFT feldolgozás sikertelen!\n");
    }
    DEBUG("\n=== TESZT 2: AudioProcessorCore1Integration ===\n");

    // AudioProcessor példány létrehozása a teszthez (megfelelő konstruktor paraméterekkel)
    float testGain = 1.0f;
    AudioProcessor audioProcessor(testGain, A0, 44100.0, testSize);

    // Integration layer létrehozása
    AudioProcessorCore1Integration integration(&audioProcessor);
    AudioProcessorCore1Integration::IntegrationConfig config;
    config.mode = AudioProcessorCore1Integration::ProcessingMode::AUTO_FAILOVER;
    config.enableAutoFallback = true;
    config.core1TimeoutMs = 500;
    config.fallbackThresholdMs = 1000;
    config.hybridLoadThreshold = 80;
    config.enablePerformanceMonitoring = true;
    config.enableDetailedLogging = false;

    if (!integration.initialize(config)) {
        DEBUG("HIBA: AudioProcessorCore1Integration inicializálás sikertelen!\n");
        processor.shutdown();
        return;
    }
    DEBUG("✓ AudioProcessorCore1Integration inicializálva\n");

    // Egyszerű FFT teszt
    startTime = millis();
    success = integration.processFFT(testInput.data(), testSize, testOutput.data());
    duration = millis() - startTime;

    if (success) {
        DEBUG("✓ Integration FFT feldolgozás sikeres\n");
        DEBUG("  Feldolgozási idő: %lu ms\n", duration);
        DEBUG("  Jelenlegi mód: %d\n", (int)integration.getCurrentMode());
    } else {
        DEBUG("✗ Integration FFT feldolgozás sikertelen!\n");
    }

    DEBUG("\n=== TESZT 3: Aszinkron feldolgozás ===\n");

    integration.switchProcessingMode(AudioProcessorCore1Integration::ProcessingMode::CORE1_ONLY);

    // Aszinkron feladat indítása
    startTime = millis();
    uint32_t taskId = integration.processFFTAsync(testInput.data(), testSize, testOutput.data());

    if (taskId > 0) {
        DEBUG("✓ Aszinkron feladat elindítva (ID: %lu)\n", taskId);

        // Várakozás a befejezésre
        int attempts = 0;

        while (attempts < 50) {  // Max 500ms várakozás
            delay(10);
            integration.update();
            attempts++;
        }

        duration = millis() - startTime;
        DEBUG("✓ Aszinkron feldolgozás teszt befejezve (%lu ms)\n", duration);
    } else {
        DEBUG("✗ Aszinkron feladat elindítása sikertelen!\n");
    }

    DEBUG("\n=== TESZT 4: Teljesítmény statisztikák ===\n");
    auto stats = integration.getStats();
    DEBUG("Teljesítmény statisztikák:\n");
    DEBUG("  Összes FFT feldolgozás: %lu\n", stats.totalFFTProcessed);
    DEBUG("  Core0 FFT: %lu, Core1 FFT: %lu (%.1f%%)\n", stats.core0FFTCount, stats.core1FFTCount,
          stats.totalFFTProcessed > 0 ? (float)stats.core1FFTCount / stats.totalFFTProcessed * 100.0f : 0.0f);
    DEBUG("  Átlagos Core0 idő: %.2f ms, Core1 idő: %.2f ms\n", stats.averageCore0TimeMs, stats.averageCore1TimeMs);
    DEBUG("  Core1 sikeresség: %.1f%%, teljesítménynyereség: %.1fx\n", stats.core1SuccessRate, stats.performanceGain);

    DEBUG("\n=== TESZT 5: Memória hatás ===\n");

    MemoryStatus_t finalMem = getMemoryStatus();
    DEBUG("Végső memória állapot:\n");
    DEBUG("  Használt heap: %lu bytes (%.2f KB)\n", finalMem.usedHeap, finalMem.usedHeap / 1024.0f);
    DEBUG("  Szabad heap: %lu bytes (%.2f KB)\n", finalMem.freeHeap, finalMem.freeHeap / 1024.0f);
    DEBUG("Memória különbség: %ld bytes\n", (long)(finalMem.usedHeap - initialMem.usedHeap));

    // Takarítás
    integration.shutdown();
    processor.shutdown();

    DEBUG("\n================================================================\n");
    DEBUG("                    INTEGRITÁS TESZT BEFEJEZVE                  \n");
    DEBUG("================================================================\n");
}

/**
 * @brief Gyors funkcionális teszt a kritikus funkciókhoz
 */
void runQuickCore1Test() {
    DEBUG("\n=== GYORS CORE1 FUNKCIONÁLIS TESZT ===\n");

    // Minimális teszt adatok
    const uint16_t size = 64;
    float input[size];
    float output[size];

    // Egyszerű teszt jel
    for (uint16_t i = 0; i < size; i++) {
        input[i] = sin(2.0f * PI * i / size);
    }

    // Core1 processzor teszt
    Core1FftProcessor processor;
    if (processor.initialize()) {
        if (processor.processFFTSync(input, size, output, true)) {
            DEBUG("✓ Core1 FFT alapfunkció működik\n");
        } else {
            DEBUG("✗ Core1 FFT alapfunkció hiba\n");
        }
        processor.shutdown();
    } else {
        DEBUG("✗ Core1 processzor inicializálás hiba\n");
    }

    DEBUG("✓ Gyors teszt befejezve\n");
}
