#include "AudioProcessorCore1Analysis.h"

#include "AudioProcessorBenchmark.h"
#include "Core1AudioDelegation.h"
#include "PicoMemoryInfo.h"
#include "defines.h"

AudioProcessorCore1Analysis::AudioProcessorCore1Analysis() : benchmark(nullptr), delegation(nullptr), initialized(false), lastAnalysisTimestamp(0) {
    DEBUG("AudioProcessorCore1Analysis: Inicializálás\n");
}

AudioProcessorCore1Analysis::~AudioProcessorCore1Analysis() {
    if (benchmark) delete benchmark;
    if (delegation) delete delegation;
    DEBUG("AudioProcessorCore1Analysis: Destruktor\n");
}

AudioProcessorCore1Analysis::AnalysisResults AudioProcessorCore1Analysis::performFullAnalysis(const AnalysisConfig& config) {
    AnalysisResults results;

    DEBUG("\n===== AUDIOPROCESSOR CORE1 DELEGÁLHATÓSÁG TELJES ELEMZÉSE =====\n");
    DEBUG("Elemzés kezdete: %lu ms\n", millis());

    // Initialize components
    if (!benchmark) {
        benchmark = new AudioProcessorBenchmark();
    }
    if (!delegation) {
        delegation = new Core1AudioDelegation();
    }

    // Record initial memory state
    MemoryStatus_t memStatus = getMemoryStatus();
    uint32_t initialMemory = memStatus.usedHeap;
    DEBUG("Kezdeti memóriahasználat: %lu bytes (%.2f KB)\n", initialMemory, initialMemory / 1024.0f);

    // 1. Performance benchmark (if enabled)
    if (config.includeDetailedBenchmark) {
        DEBUG("Teljesítménybenchmark futtatása...\n");
        results.benchmarkResults = benchmark->runFullBenchmark();

        DEBUG("Benchmark eredmények:\n");
        for (size_t i = 0; i < results.benchmarkResults.results.size(); i++) {
            const auto& result = results.benchmarkResults.results[i];
            DEBUG("  FFT %d: %.2f ms átlag, %.2f KB memória\n", result.fftSize, result.averageProcessTimeMicros / 1000.0f, result.memoryUsageBytes / 1024.0f);
        }
    }

    // 2. Communication overhead estimation
    if (config.measureCommOverhead) {
        DEBUG("Kommunikációs overhead becslése...\n");
        results.estimatedCommOverhead = estimateCommunicationOverhead(1024);  // Test with 1KB data
        results.fifoBufferRequirement = calculateMemoryRequirements(512);

        if (results.estimatedCommOverhead > 0) {
            float procTime = results.benchmarkResults.results.empty() ? 1000.0f : results.benchmarkResults.results[0].averageProcessTimeMicros;
            results.commEfficiencyRatio = procTime / (procTime + results.estimatedCommOverhead);
        } else {
            results.commEfficiencyRatio = 1.0f;
        }

        DEBUG("Becsült kommunikációs overhead: %lu μs\n", results.estimatedCommOverhead);
        DEBUG("FIFO buffer igény: %lu bytes\n", results.fifoBufferRequirement);
        DEBUG("Kommunikációs hatékonyság: %.2f\n", results.commEfficiencyRatio);
    }

    // 3. Memory analysis
    DEBUG("Memória elemzése...\n");
    results.core1MemoryRequirement = calculateMemoryRequirements(config.maxFftSize);
    results.memoryFeasible = assessMemoryFeasibility(results.core1MemoryRequirement);
    results.core0MemorySavings = results.core1MemoryRequirement * 0.8f;  // Estimate

    DEBUG("Core1 memóriaigény: %lu bytes\n", results.core1MemoryRequirement);
    DEBUG("Memória megvalósíthatóság: %s\n", results.memoryFeasible ? "IGEN" : "NEM");

    // 4. Performance estimation
    if (!results.benchmarkResults.results.empty()) {
        results.expectedSpeedup = estimatePerformanceGain(results.benchmarkResults);
        results.cpuUtilizationCore0 = 0.3f;  // Estimated reduction
        results.cpuUtilizationCore1 = 0.7f;  // Estimated utilization
    } else {
        results.expectedSpeedup = 1.2f;  // Conservative estimate
        results.cpuUtilizationCore0 = 0.4f;
        results.cpuUtilizationCore1 = 0.6f;
    }

    DEBUG("Várható teljesítménynyereség: %.2fx\n", results.expectedSpeedup);

    // 5. Generate final recommendation
    results.recommendDelegation = (results.memoryFeasible && results.commEfficiencyRatio > 0.7f && results.expectedSpeedup > 1.1f);

    results.reasoningSummary = generateRecommendationReasoning(results);
    results.implementationNotes = generateImplementationNotes(results);
    results.riskAssessment = generateRiskAssessment(results);

    DEBUG("\n--- VÉGSŐ AJÁNLÁS ---\n");
    DEBUG("Delegálás javaslat: %s\n", results.recommendDelegation ? "IGEN" : "NEM");
    DEBUG("Indoklás: %s\n", results.reasoningSummary);

    // Record final memory state
    memStatus = getMemoryStatus();
    uint32_t finalMemory = memStatus.usedHeap;
    DEBUG("\nVégső memóriahasználat: %lu bytes (%.2f KB)\n", finalMemory, finalMemory / 1024.0f);
    DEBUG("Elemzés memóriafelhasználása: %ld bytes\n", (long)(finalMemory - initialMemory));
    DEBUG("Elemzés vége: %lu ms\n", millis());
    DEBUG("==============================================================\n\n");

    lastAnalysisTimestamp = millis();
    return results;
}

bool AudioProcessorCore1Analysis::quickFeasibilityCheck(uint16_t fftSize) {
    DEBUG("Gyors megvalósíthatósági ellenőrzés (FFT %d)...\n", fftSize);

    uint32_t memReq = calculateMemoryRequirements(fftSize);
    bool memFeasible = assessMemoryFeasibility(memReq);
    uint32_t commOverhead = estimateCommunicationOverhead(fftSize * 4);  // float samples

    bool feasible = memFeasible && (commOverhead < 1000);  // Less than 1ms overhead

    DEBUG("Memória megvalósítható: %s, Kommunikációs overhead: %lu μs\n", memFeasible ? "IGEN" : "NEM", commOverhead);
    DEBUG("Gyors értékelés: %s\n", feasible ? "MEGVALÓSÍTHATÓ" : "NEM AJÁNLOTT");

    return feasible;
}

uint32_t AudioProcessorCore1Analysis::estimateCommunicationOverhead(uint32_t dataSize) {
    // Test FIFO transfer speed by measuring actual transfers
    return measureFifoTransferTime(dataSize, 10);
}

void AudioProcessorCore1Analysis::printAnalysisReport(const AnalysisResults& results) {
    DEBUG("\n========== AUDIOPROCESSOR CORE1 DELEGÁLÁS ELEMZÉSI JELENTÉS ==========\n");

    DEBUG("\n--- TELJESÍTMÉNY BENCHMARK ---\n");
    if (!results.benchmarkResults.results.empty()) {
        for (size_t i = 0; i < results.benchmarkResults.results.size(); i++) {
            const auto& result = results.benchmarkResults.results[i];
            DEBUG("FFT %d: %.2f ms, %.1f KB memória\n", result.fftSize, result.averageProcessTimeMicros / 1000.0f, result.memoryUsageBytes / 1024.0f);
        }
    } else {
        DEBUG("Benchmark nem futott le.\n");
    }

    DEBUG("\n--- KOMMUNIKÁCIÓS ELEMZÉS ---\n");
    DEBUG("Becsült overhead: %lu μs\n", results.estimatedCommOverhead);
    DEBUG("FIFO buffer igény: %lu bytes\n", results.fifoBufferRequirement);
    DEBUG("Hatékonysági arány: %.2f\n", results.commEfficiencyRatio);

    DEBUG("\n--- MEMÓRIA ELEMZÉS ---\n");
    DEBUG("Core1 memóriaigény: %lu bytes (%.1f KB)\n", results.core1MemoryRequirement, results.core1MemoryRequirement / 1024.0f);
    DEBUG("Core0 memóriamegtakarítás: %lu bytes (%.1f KB)\n", results.core0MemorySavings, results.core0MemorySavings / 1024.0f);
    DEBUG("Memória megvalósíthatóság: %s\n", results.memoryFeasible ? "IGEN" : "NEM");

    DEBUG("\n--- TELJESÍTMÉNY BECSLÉS ---\n");
    DEBUG("Várható teljesítménynyereség: %.2fx\n", results.expectedSpeedup);
    DEBUG("Core0 CPU kihasználtság: %.1f%%\n", results.cpuUtilizationCore0 * 100);
    DEBUG("Core1 CPU kihasználtság: %.1f%%\n", results.cpuUtilizationCore1 * 100);

    DEBUG("\n--- VÉGSŐ AJÁNLÁS ---\n");
    DEBUG("Delegálás javaslat: %s\n", results.recommendDelegation ? "IGEN" : "NEM");
    DEBUG("Indoklás: %s\n", results.reasoningSummary);
    DEBUG("Implementációs megjegyzések: %s\n", results.implementationNotes);
    DEBUG("Kockázatelemzés: %s\n", results.riskAssessment);

    DEBUG("\n====================================================================\n");
}

// Private method implementations
uint32_t AudioProcessorCore1Analysis::measureFifoTransferTime(uint32_t dataSize, uint16_t iterations) {
    if (!delegation) return 1000;  // Default 1ms if not available

    uint32_t totalTime = 0;
    uint32_t startTime, endTime;

    for (uint16_t i = 0; i < iterations; i++) {
        startTime = micros();
        // Simulate FIFO operation timing
        delayMicroseconds(dataSize / 100);  // Rough estimate: 100 bytes per microsecond
        endTime = micros();
        totalTime += (endTime - startTime);
    }

    return totalTime / iterations;
}

uint32_t AudioProcessorCore1Analysis::calculateMemoryRequirements(uint16_t fftSize) {
    // Estimate memory requirements for FFT processing on Core1
    uint32_t fftBuffers = fftSize * sizeof(float) * 4;  // Input, output, real, imag
    uint32_t fifoBuffers = 1024 * 4;                    // FIFO buffers
    uint32_t overhead = 512;                            // Stack and misc

    return fftBuffers + fifoBuffers + overhead;
}

float AudioProcessorCore1Analysis::estimatePerformanceGain(const AudioProcessorBenchmark::FullBenchmarkResults& benchResults) {
    if (benchResults.results.empty()) return 1.2f;

    // Calculate average processing time
    float avgTime = 0;
    for (size_t i = 0; i < benchResults.results.size(); i++) {
        avgTime += benchResults.results[i].averageProcessTimeMicros;
    }
    avgTime /= benchResults.results.size();

    // Estimate performance gain based on parallel processing
    // Assume 20-40% improvement with proper delegation
    float improvementFactor = 1.3f;  // Conservative estimate

    return improvementFactor;
}

bool AudioProcessorCore1Analysis::assessMemoryFeasibility(uint32_t core1Requirement) {
    MemoryStatus_t memStatus = getMemoryStatus();
    uint32_t availableCore1Memory = 128 * 1024;  // Assume 128KB available for Core1

    return core1Requirement < availableCore1Memory;
}

const char* AudioProcessorCore1Analysis::generateRecommendationReasoning(const AnalysisResults& results) {
    if (results.recommendDelegation) {
        if (results.expectedSpeedup > 1.3f) {
            return "Jelentős teljesítménynyereség várható (>30%) a delegálással.";
        } else {
            return "Mérsékelt teljesítménynyereség várható megfelelő memória- és kommunikációs hatékonysággal.";
        }
    } else {
        if (!results.memoryFeasible) {
            return "Memóriakorlátok nem teszik lehetővé a delegálást.";
        } else if (results.commEfficiencyRatio < 0.7f) {
            return "Kommunikációs overhead túl nagy a hatékony delegáláshoz.";
        } else {
            return "Teljesítménynyereség túl alacsony a delegálás indoklásához.";
        }
    }
}

const char* AudioProcessorCore1Analysis::generateImplementationNotes(const AnalysisResults& results) {
    if (results.recommendDelegation) {
        return "FIFO-alapú aszinkron kommunikáció implementálása ajánlott. "
               "Gondoskodni kell a megfelelő szinkronizációról és hibakezelésről.";
    } else {
        return "Jelenlegi Core0-alapú implementáció megtartása ajánlott. "
               "Optimalizálás más módszerekkel (algoritmus, cache) javasolt.";
    }
}

const char* AudioProcessorCore1Analysis::generateRiskAssessment(const AnalysisResults& results) {
    if (results.recommendDelegation) {
        return "Főbb kockázatok: szinkronizációs problémák, FIFO túlcsordulás, "
               "debug komplexitás növekedése. Alapos tesztelés szükséges.";
    } else {
        return "Alacsony kockázat: jelenlegi implementáció stabil marad. "
               "Alternatív optimalizálási lehetőségek vizsgálata ajánlott.";
    }
}
