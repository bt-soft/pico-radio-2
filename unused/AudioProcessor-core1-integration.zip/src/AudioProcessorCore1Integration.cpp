#include "AudioProcessorCore1Integration.h"

#include <algorithm>
#include <cstring>

#include "PicoMemoryInfo.h"
#include "hardware/timer.h"
#include "pico/stdlib.h"

AudioProcessorCore1Integration::AudioProcessorCore1Integration(AudioProcessor* audioProcessor)
    : core1Processor_(nullptr),
      taskManager_(nullptr),
      audioProcessor_(audioProcessor),
      initialized_(false),
      enabled_(false),
      lastPerformanceCheck_(0),
      lastCore1Failure_(0),
      consecutiveFailures_(0) {
    DEBUG("AudioProcessorCore1Integration: Konstruktor\n");

    if (!audioProcessor_) {
        DEBUG("AudioProcessorCore1Integration: HIBA - Null AudioProcessor referencia\n");
        return;
    }

    // Alapértelmezett konfiguráció beállítása
    config_ = getDefaultConfig();

    // Statisztikák inicializálása
    memset(&stats_, 0, sizeof(stats_));
    stats_.currentMode = config_.mode;

    // Teljesítmény history inicializálása
    initializePerformanceHistory();
}

AudioProcessorCore1Integration::~AudioProcessorCore1Integration() {
    DEBUG("AudioProcessorCore1Integration: Destruktor kezdete\n");
    if (initialized_) {
        shutdown();
    }
    DEBUG("AudioProcessorCore1Integration: Destruktor vége\n");
}

bool AudioProcessorCore1Integration::initialize(const IntegrationConfig& config) {
    DEBUG("AudioProcessorCore1Integration: Inicializálás kezdete\n");

    if (initialized_) {
        DEBUG("AudioProcessorCore1Integration: Már inicializálva\n");
        return true;
    }

    if (!audioProcessor_) {
        DEBUG("AudioProcessorCore1Integration: HIBA - Null AudioProcessor referencia\n");
        return false;
    }

    // Konfiguráció validálása
    if (!validateConfig(config)) {
        DEBUG("AudioProcessorCore1Integration: HIBA - Érvénytelen konfiguráció\n");
        return false;
    }

    config_ = config;

    // Core1 komponensek inicializálása
    if (config_.mode != ProcessingMode::CORE0_ONLY) {
        DEBUG("AudioProcessorCore1Integration: Core1 komponensek inicializálása...\n");

        // Core1FftProcessor létrehozása
        core1Processor_ = new Core1FftProcessor();
        if (!core1Processor_) {
            DEBUG("AudioProcessorCore1Integration: HIBA - Core1FftProcessor allokálás sikertelen\n");
            return false;
        }

        if (!core1Processor_->initialize()) {
            DEBUG("AudioProcessorCore1Integration: HIBA - Core1FftProcessor inicializálás sikertelen\n");
            delete core1Processor_;
            core1Processor_ = nullptr;
            return false;
        }

        // Core1AsyncTaskManager létrehozása
        taskManager_ = new Core1AsyncTaskManager(core1Processor_);
        if (!taskManager_) {
            DEBUG("AudioProcessorCore1Integration: HIBA - Core1AsyncTaskManager allokálás sikertelen\n");
            core1Processor_->shutdown();
            delete core1Processor_;
            core1Processor_ = nullptr;
            return false;
        }

        if (!taskManager_->initialize()) {
            DEBUG("AudioProcessorCore1Integration: HIBA - Core1AsyncTaskManager inicializálás sikertelen\n");
            delete taskManager_;
            taskManager_ = nullptr;
            core1Processor_->shutdown();
            delete core1Processor_;
            core1Processor_ = nullptr;
            return false;
        }

        stats_.core1Available = true;
        DEBUG("AudioProcessorCore1Integration: Core1 komponensek sikeresen inicializálva\n");
    } else {
        stats_.core1Available = false;
        DEBUG("AudioProcessorCore1Integration: CORE0_ONLY mód - Core1 komponensek kihagyása\n");
    }

    // Core0 mindig elérhető
    stats_.core0Active = true;

    initialized_ = true;
    enabled_ = true;
    lastPerformanceCheck_ = time_us_32();

    DEBUG("AudioProcessorCore1Integration: Inicializálás sikeres - Mód: %d\n", static_cast<int>(config_.mode));
    return true;
}

void AudioProcessorCore1Integration::shutdown() {
    DEBUG("AudioProcessorCore1Integration: Leállítás kezdete\n");

    if (!initialized_) {
        DEBUG("AudioProcessorCore1Integration: Nincs mit leállítani\n");
        return;
    }

    enabled_ = false;

    // TaskManager leállítása
    if (taskManager_) {
        taskManager_->shutdown();
        delete taskManager_;
        taskManager_ = nullptr;
    }

    // Core1Processor leállítása
    if (core1Processor_) {
        core1Processor_->shutdown();
        delete core1Processor_;
        core1Processor_ = nullptr;
    }

    stats_.core1Available = false;
    initialized_ = false;

    DEBUG("AudioProcessorCore1Integration: Leállítás befejezve\n");
}

bool AudioProcessorCore1Integration::processFFT(const float* inputData, uint16_t fftSize, float* outputBuffer, bool forceCore0) {
    if (!initialized_ || !enabled_ || !inputData || !outputBuffer) {
        DEBUG("AudioProcessorCore1Integration: HIBA - Érvénytelen állapot vagy paraméterek\n");
        return false;
    }

    // Core kiválasztása
    bool useCore1 = false;
    if (!forceCore0 && config_.mode != ProcessingMode::CORE0_ONLY && stats_.core1Available) {
        switch (config_.mode) {
            case ProcessingMode::CORE1_ONLY:
                useCore1 = true;
                break;
            case ProcessingMode::HYBRID:
                useCore1 = shouldUseCore1ForHybrid();
                break;
            case ProcessingMode::AUTO_FAILOVER:
                useCore1 = (consecutiveFailures_ < MAX_CONSECUTIVE_FAILURES) && (time_us_32() - lastCore1Failure_ > FALLBACK_COOLDOWN_MS * 1000);
                break;
            default:
                useCore1 = false;
                break;
        }
    }

    uint32_t processingTime = 0;
    bool success = false;

    if (useCore1) {
        // Core1 feldolgozás
        processingTime = processFFTCore1(inputData, fftSize, outputBuffer);
        success = (processingTime > 0);

        if (!success && config_.enableAutoFallback) {
            DEBUG("AudioProcessorCore1Integration: Core1 hiba, fallback Core0-ra\n");
            handleCore1Failure("FFT processing failed");

            // Fallback Core0-ra
            processingTime = processFFTCore0(inputData, fftSize, outputBuffer);
            success = (processingTime > 0);
            useCore1 = false;
        }
    } else {
        // Core0 feldolgozás
        processingTime = processFFTCore0(inputData, fftSize, outputBuffer);
        success = (processingTime > 0);
    }

    // Statisztikák frissítése
    updateStats(useCore1, success, processingTime / 1000);  // mikroszekundum -> milliszekundum
    updatePerformanceData(useCore1, processingTime / 1000);

    if (config_.enableDetailedLogging && success) {
        DEBUG("AudioProcessorCore1Integration: FFT kész - Core: %s, Idő: %lu μs\n", useCore1 ? "Core1" : "Core0", processingTime);
    }

    return success;
}

uint32_t AudioProcessorCore1Integration::processFFTAsync(const float* inputData, uint16_t fftSize, float* outputBuffer, std::function<void(bool, uint32_t)> callback) {
    if (!initialized_ || !enabled_ || !taskManager_ || !stats_.core1Available) {
        DEBUG("AudioProcessorCore1Integration: HIBA - Aszinkron feldolgozás nem elérhető\n");
        return 0;
    }

    // Aszinkron feladat beküldése
    return taskManager_->submitFFTTask(
        inputData, fftSize, outputBuffer, Core1AsyncTaskManager::TaskPriority::NORMAL,
        [this, callback](const Core1AsyncTaskManager::FftTask& task, bool success) {
            // Statisztikák frissítése
            uint32_t processingTime = task.completedTime - task.startedTime;
            updateStats(true, success, processingTime);
            updatePerformanceData(true, processingTime);

            if (callback) {
                callback(success, processingTime);
            }
        },
        config_.core1TimeoutMs);
}

void AudioProcessorCore1Integration::process(bool collectOsciSamples) {
    if (!initialized_ || !audioProcessor_) {
        DEBUG("AudioProcessorCore1Integration: process() - Nincs inicializálva vagy nincs AudioProcessor\n");
        return;
    }

    // Az update() függvény hívása a statisztikák és monitoring frissítéséhez
    update();

    // Az eredeti AudioProcessor process() metódusának hívása
    // Ez az egyszerű megoldás, ami kompatibilis az eredeti API-val
    // A későbbiekben ez továbbfejleszthető, hogy a tényleges FFT feldolgozást
    // Core1-en végezze, de az AudioProcessor sok más funkciót is tartalmaz
    // (ADC olvasás, előfeldolgozás, stb.) amit Core0-n kell hagyni
    audioProcessor_->process(collectOsciSamples);

    // Statisztikák frissítése (Core0 használat jelzése)
    updateStats(false, true, 0);  // Core0, sikeres, idő ismeretlen ebben a kontextusban
}

bool AudioProcessorCore1Integration::switchProcessingMode(ProcessingMode mode) {
    if (!initialized_) {
        DEBUG("AudioProcessorCore1Integration: HIBA - Nincs inicializálva\n");
        return false;
    }

    if (mode == config_.mode) {
        DEBUG("AudioProcessorCore1Integration: Mód már beállítva: %d\n", static_cast<int>(mode));
        return true;
    }

    DEBUG("AudioProcessorCore1Integration: Mód váltás: %d -> %d\n", static_cast<int>(config_.mode), static_cast<int>(mode));

    config_.mode = mode;
    stats_.currentMode = mode;
    stats_.lastSwitchTimestamp = time_us_32();

    return true;
}

void AudioProcessorCore1Integration::optimizePerformance() {
    if (!initialized_ || !config_.enablePerformanceMonitoring) {
        return;
    }

    uint32_t currentTime = time_us_32();
    if (currentTime - lastPerformanceCheck_ < 5000000) {  // 5 másodperc
        return;
    }

    lastPerformanceCheck_ = currentTime;

    // Teljesítmény trend elemzése
    if (analyzePerformanceTrend()) {
        // Automatikus mód váltás ha szükséges
        handleAutoModeSwitch();
    }

    // Optimális állapot frissítése
    if (stats_.core1Available && !core1Times_.empty() && !core0Times_.empty()) {
        float avgCore1 = 0, avgCore0 = 0;
        for (uint32_t time : core1Times_) avgCore1 += time;
        for (uint32_t time : core0Times_) avgCore0 += time;

        avgCore1 /= core1Times_.size();
        avgCore0 /= core0Times_.size();

        stats_.isOptimal = (config_.mode == ProcessingMode::CORE1_ONLY && avgCore1 < avgCore0) || (config_.mode == ProcessingMode::CORE0_ONLY && avgCore0 <= avgCore1) ||
                           (config_.mode == ProcessingMode::HYBRID) || (config_.mode == ProcessingMode::AUTO_FAILOVER && avgCore1 < avgCore0);
    }
}

void AudioProcessorCore1Integration::update() {
    if (!initialized_ || !enabled_) {
        return;
    }

    // Teljesítmény optimalizálás
    optimizePerformance();

    // TaskManager frissítése
    if (taskManager_) {
        taskManager_->update();
    }

    // Core1 health check
    if (stats_.core1Available && core1Processor_) {
        if (!core1Processor_->isCore1Running()) {
            DEBUG("AudioProcessorCore1Integration: FIGYELEM - Core1 nem válaszol\n");
            stats_.core1Available = false;
        }
    }
}

AudioProcessorCore1Integration::IntegrationStats AudioProcessorCore1Integration::getStats() const { return stats_; }

bool AudioProcessorCore1Integration::isCore1Available() const { return stats_.core1Available && core1Processor_ && core1Processor_->isCore1Running(); }

void AudioProcessorCore1Integration::printPerformanceReport(bool detailed) const {
    DEBUG("\n=== AudioProcessor Core1 Integration Performance Report ===\n");
    DEBUG("Mód: %d, Core1 elérhető: %s, Inicializálva: %s\n", static_cast<int>(stats_.currentMode), stats_.core1Available ? "igen" : "nem", initialized_ ? "igen" : "nem");

    DEBUG("Összes FFT: %lu, Core0: %lu, Core1: %lu\n", stats_.totalFFTProcessed, stats_.core0FFTCount, stats_.core1FFTCount);

    DEBUG("Core1 sikeresség: %.1f%%, Hibák: %lu, Fallback: %lu\n", stats_.core1SuccessRate, stats_.core1Failures, stats_.fallbackEvents);

    DEBUG("Átlag Core0: %.2f ms, Átlag Core1: %.2f ms\n", stats_.averageCore0TimeMs, stats_.averageCore1TimeMs);

    DEBUG("Teljesítménynyereség: %.1f%%, Optimális: %s\n", stats_.performanceGain, stats_.isOptimal ? "igen" : "nem");

    if (detailed) {
        DEBUG("--- Részletes adatok ---\n");
        DEBUG("Utolsó váltás: %lu, Utolsó Core1 hiba: %lu\n", stats_.lastSwitchTimestamp, lastCore1Failure_);
        DEBUG("Sorozatos hibák: %lu/%lu\n", consecutiveFailures_, MAX_CONSECUTIVE_FAILURES);

        if (core1Processor_) {
            auto core1Stats = core1Processor_->getStats();
            DEBUG("Core1 parancsok: %lu sikeres / %lu összes\n", core1Stats.successfulCommands, core1Stats.totalCommands);
            DEBUG("Core1 átlag idő: %lu μs, max: %lu μs\n", core1Stats.averageProcessingTimeMicros, core1Stats.maxProcessingTimeMicros);
        }
    }
    DEBUG("=== Jelentés vége ===\n\n");
}

bool AudioProcessorCore1Integration::updateConfig(const IntegrationConfig& config) {
    if (!validateConfig(config)) {
        DEBUG("AudioProcessorCore1Integration: HIBA - Érvénytelen konfiguráció\n");
        return false;
    }

    config_ = config;
    stats_.currentMode = config_.mode;

    DEBUG("AudioProcessorCore1Integration: Konfiguráció frissítve\n");
    return true;
}

bool AudioProcessorCore1Integration::pingCore1() const {
    if (!core1Processor_) {
        return false;
    }

    return core1Processor_->pingCore1(1000);  // 1 másodperc timeout
}

// ============================================================================
// PRIVÁT METÓDUSOK
// ============================================================================

uint32_t AudioProcessorCore1Integration::processFFTCore0(const float* inputData, uint16_t fftSize, float* outputBuffer) {
    if (!audioProcessor_ || !inputData || !outputBuffer) {
        DEBUG("AudioProcessorCore1Integration: processFFTCore0 - Érvénytelen paraméterek\n");
        return 0;
    }

    uint32_t startTime = time_us_32();

    // Core0 FFT feldolgozás az eredeti AudioProcessor-rel
    // Az AudioProcessor-t úgy használjuk, hogy az saját belső adat struktúráit használja
    // és nem külső buffereket

    // A jelenlegi implementáció azt jelenti, hogy az AudioProcessor
    // saját belső mintavételezést és FFT-t végez
    // Itt csak meghívjuk a process függvényt
    audioProcessor_->process(false);  // nem kell oszcilloszkóp

    // Az eredményeket kimásoljuk az outputBuffer-be
    const double* magnitudeData = audioProcessor_->getMagnitudeData();
    uint16_t actualSize = audioProcessor_->getFftSize();
    uint16_t outputSize = std::min(fftSize, actualSize);

    for (uint16_t i = 0; i < outputSize; i++) {
        outputBuffer[i] = static_cast<float>(magnitudeData[i]);
    }

    // Fennmaradó helyek nullázása ha szükséges
    for (uint16_t i = outputSize; i < fftSize; i++) {
        outputBuffer[i] = 0.0f;
    }

    uint32_t processingTime = time_us_32() - startTime;

    if (config_.enableDetailedLogging) {
        DEBUG("AudioProcessorCore1Integration: Core0 FFT feldolgozás kész - %lu μs\n", processingTime);
    }

    return processingTime;
}

uint32_t AudioProcessorCore1Integration::processFFTCore1(const float* inputData, uint16_t fftSize, float* outputBuffer) {
    if (!initialized_ || !enabled_ || !taskManager_ || !inputData || !outputBuffer) {
        DEBUG("AudioProcessorCore1Integration: processFFTCore1 - Érvénytelen állapot vagy paraméterek\n");
        return 0;
    }

    if (!stats_.core1Available) {
        DEBUG("AudioProcessorCore1Integration: processFFTCore1 - Core1 nem elérhető\n");
        return 0;
    }

    uint32_t startTime = time_us_32();  // Core1 FFT feldolgozás TaskManager-en keresztül
    bool success = false;
    uint32_t timeoutMs = config_.core1TimeoutMs;

    // FFT feladat küldése Core1-re a TaskManager API-n keresztül
    uint32_t taskId = taskManager_->submitFFTTask(inputData, fftSize, outputBuffer, Core1AsyncTaskManager::TaskPriority::NORMAL,
                                                  nullptr,  // No callback for synchronous processing
                                                  timeoutMs);

    if (taskId > 0) {
        // Várakozás a feldolgozás befejezésére
        uint32_t waitStart = time_us_32();
        uint32_t timeoutUs = timeoutMs * 1000;

        Core1AsyncTaskManager::TaskStatus status;
        do {
            taskManager_->update();
            status = taskManager_->getTaskStatus(taskId);
            sleep_us(100);  // Rövid várakozás
        } while ((status == Core1AsyncTaskManager::TaskStatus::PENDING || status == Core1AsyncTaskManager::TaskStatus::PROCESSING) && (time_us_32() - waitStart) < timeoutUs);

        if (status == Core1AsyncTaskManager::TaskStatus::COMPLETED) {
            Core1FftProcessor::FftResult result;
            if (taskManager_->getTaskResult(taskId, result)) {
                success = result.success;
                if (success) {
                    if (config_.enableDetailedLogging) {
                        DEBUG("AudioProcessorCore1Integration: Core1 FFT feldolgozás sikeres\n");
                    }
                } else {
                    DEBUG("AudioProcessorCore1Integration: Core1 FFT feldolgozás sikertelen\n");
                }
            } else {
                DEBUG("AudioProcessorCore1Integration: Core1 FFT eredmény lekérése sikertelen\n");
                success = false;
            }
        } else if (status == Core1AsyncTaskManager::TaskStatus::TIMEOUT) {
            DEBUG("AudioProcessorCore1Integration: Core1 FFT timeout\n");
            success = false;
        } else {
            DEBUG("AudioProcessorCore1Integration: Core1 FFT feladat hibás állapot: %d\n", static_cast<int>(status));
            success = false;
        }
    } else {
        DEBUG("AudioProcessorCore1Integration: Core1 FFT feladat küldése sikertelen\n");
        success = false;
    }

    uint32_t processingTime = time_us_32() - startTime;

    if (!success) {
        // Hiba esetén nullázzuk az output buffert
        memset(outputBuffer, 0, fftSize * sizeof(float));
        return 0;
    }

    return processingTime;
}

bool AudioProcessorCore1Integration::selectOptimalCore(uint16_t fftSize) {
    // Egyszerű heurisztika: nagyobb FFT méretekhez Core1
    if (fftSize >= 512) {
        return stats_.core1Available;
    }

    // Teljesítmény history alapú döntés
    if (!core0Times_.empty() && !core1Times_.empty()) {
        float avgCore0 = 0, avgCore1 = 0;
        for (uint32_t time : core0Times_) avgCore0 += time;
        for (uint32_t time : core1Times_) avgCore1 += time;

        avgCore0 /= core0Times_.size();
        avgCore1 /= core1Times_.size();

        return (avgCore1 < avgCore0 * 0.9f);  // 10% küszöb
    }

    return stats_.core1Available;
}

bool AudioProcessorCore1Integration::shouldUseCore1ForHybrid() {
    if (!stats_.core1Available) {
        return false;
    }

    // Terhelés alapú döntés
    if (core1Processor_) {
        auto core1Stats = core1Processor_->getStats();
        if (core1Stats.currentLoad > config_.hybridLoadThreshold) {
            return false;
        }
    }

    // Hibák száma alapú döntés
    if (consecutiveFailures_ >= MAX_CONSECUTIVE_FAILURES) {
        return false;
    }

    return true;
}

void AudioProcessorCore1Integration::handleCore1Failure(const char* reason) {
    consecutiveFailures_++;
    lastCore1Failure_ = time_us_32();
    stats_.core1Failures++;
    stats_.fallbackEvents++;

    DEBUG("AudioProcessorCore1Integration: Core1 hiba (#%lu): %s\n", consecutiveFailures_, reason);

    if (consecutiveFailures_ >= MAX_CONSECUTIVE_FAILURES) {
        DEBUG("AudioProcessorCore1Integration: Túl sok hiba, átkapcsolás Core0-ra\n");
        if (config_.mode == ProcessingMode::AUTO_FAILOVER) {
            // Időleges váltás Core0-ra
        }
    }
}

void AudioProcessorCore1Integration::updatePerformanceData(bool isCore1, uint32_t processingTimeMs) {
    if (isCore1) {
        core1Times_.push_back(processingTimeMs);
        if (core1Times_.size() > PERF_HISTORY_SIZE) {
            core1Times_.erase(core1Times_.begin());
        }
    } else {
        core0Times_.push_back(processingTimeMs);
        if (core0Times_.size() > PERF_HISTORY_SIZE) {
            core0Times_.erase(core0Times_.begin());
        }
    }

    // Átlagok frissítése
    if (!core0Times_.empty()) {
        float sum = 0;
        for (uint32_t time : core0Times_) sum += time;
        stats_.averageCore0TimeMs = sum / core0Times_.size();
    }

    if (!core1Times_.empty()) {
        float sum = 0;
        for (uint32_t time : core1Times_) sum += time;
        stats_.averageCore1TimeMs = sum / core1Times_.size();
    }

    // Teljesítménynyereség kiszámítása
    if (stats_.averageCore0TimeMs > 0 && stats_.averageCore1TimeMs > 0) {
        stats_.performanceGain = ((stats_.averageCore0TimeMs - stats_.averageCore1TimeMs) / stats_.averageCore0TimeMs) * 100.0f;
    }
}

bool AudioProcessorCore1Integration::analyzePerformanceTrend() {
    if (core0Times_.size() < 3 || core1Times_.size() < 3) {
        return false;  // Nincs elég adat a trend elemzéshez
    }

    // Egyszerű trend elemzés: utolsó 3 mérés átlaga vs. teljes átlag
    float recentCore0 = 0, recentCore1 = 0;
    for (size_t i = core0Times_.size() - 3; i < core0Times_.size(); i++) {
        recentCore0 += core0Times_[i];
    }
    for (size_t i = core1Times_.size() - 3; i < core1Times_.size(); i++) {
        recentCore1 += core1Times_[i];
    }

    recentCore0 /= 3;
    recentCore1 /= 3;

    // Ha Core1 mostanában jelentősen jobb, akkor igaz
    return (recentCore1 < recentCore0 * 0.8f);
}

void AudioProcessorCore1Integration::handleAutoModeSwitch() {
    if (config_.mode != ProcessingMode::HYBRID && config_.mode != ProcessingMode::AUTO_FAILOVER) {
        return;
    }

    // Automatikus váltás logika
    if (analyzePerformanceTrend()) {
        // Core1 jobb teljesítményt nyújt
        if (config_.mode == ProcessingMode::HYBRID && !stats_.core1Available) {
            DEBUG("AudioProcessorCore1Integration: Auto váltás: Core1 preferált\n");
        }
    }
}

void AudioProcessorCore1Integration::updateStats(bool isCore1, bool success, uint32_t processingTimeMs) {
    stats_.totalFFTProcessed++;

    if (isCore1) {
        stats_.core1FFTCount++;
        if (!success) {
            stats_.core1Failures++;
        } else {
            consecutiveFailures_ = 0;  // Reset sikeres feldolgozás után
        }
    } else {
        stats_.core0FFTCount++;
    }

    // Core1 sikeresség arány frissítése
    if (stats_.core1FFTCount > 0) {
        stats_.core1SuccessRate = ((float)(stats_.core1FFTCount - stats_.core1Failures) / stats_.core1FFTCount) * 100.0f;
    }
}

AudioProcessorCore1Integration::IntegrationConfig AudioProcessorCore1Integration::getDefaultConfig() {
    IntegrationConfig config = {};
    config.mode = ProcessingMode::AUTO_FAILOVER;
    config.enableAutoFallback = true;
    config.core1TimeoutMs = 1000;
    config.fallbackThresholdMs = 100;
    config.hybridLoadThreshold = 80;
    config.enablePerformanceMonitoring = true;
    config.enableDetailedLogging = false;
    return config;
}

bool AudioProcessorCore1Integration::validateConfig(const IntegrationConfig& config) {
    if (config.core1TimeoutMs < 100 || config.core1TimeoutMs > 10000) {
        DEBUG("AudioProcessorCore1Integration: Érvénytelen timeout: %lu ms\n", config.core1TimeoutMs);
        return false;
    }

    if (config.hybridLoadThreshold > 100) {
        DEBUG("AudioProcessorCore1Integration: Érvénytelen terhelési küszöb: %d%%\n", config.hybridLoadThreshold);
        return false;
    }

    return true;
}

void AudioProcessorCore1Integration::initializePerformanceHistory() {
    core0Times_.clear();
    core1Times_.clear();
    core0Times_.reserve(PERF_HISTORY_SIZE);
    core1Times_.reserve(PERF_HISTORY_SIZE);
}
