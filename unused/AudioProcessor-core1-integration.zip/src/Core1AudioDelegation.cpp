#include "Core1AudioDelegation.h"

#include <pico/time.h>

#include <cstring>

#include "PicoMemoryInfo.h"
#include "defines.h"

/**
 * @brief Core1 AudioProcessor delegálás implementációja
 */

Core1AudioDelegation::Core1AudioDelegation()
    : currentState_(Core1AudioState::UNINITIALIZED),
      commandTimeoutMs_(5000),  // 5 másodperces alapértelmezett timeout
      lastCommandTimestamp_(0) {

    DEBUG("Core1AudioDelegation: Inicializálás\n");
}

Core1AudioDelegation::~Core1AudioDelegation() {
    if (currentState_ != Core1AudioState::UNINITIALIZED && currentState_ != Core1AudioState::SHUTDOWN) {
        shutdownCore1Audio();
    }
    DEBUG("Core1AudioDelegation: Destruktor\n");
}

/**
 * @brief Core1 AudioProcessor delegálás inicializálása
 */
bool Core1AudioDelegation::initializeCore1Audio(uint16_t fftSize, float gainValue, double samplingFreq) {
    DEBUG("Core1AudioDelegation: Core1 AudioProcessor inicializálása - FFT: %d, Gain: %.2f, Fs: %.1f Hz\n", fftSize, gainValue, samplingFreq);

    if (currentState_ != Core1AudioState::UNINITIALIZED) {
        DEBUG("Core1AudioDelegation: HIBA - Már inicializálva van\n");
        return false;
    }

    // Float értékek konvertálása uint32_t-vé biztonságos átvitelhez
    uint32_t gainValueBits = *reinterpret_cast<uint32_t*>(&gainValue);
    uint32_t samplingFreqBits = *reinterpret_cast<uint32_t*>(&samplingFreq);

    // Inicializációs parancs küldése
    Core1AudioMessage initMsg(CORE1_AUDIO_CMD_INIT, fftSize, gainValueBits, samplingFreqBits);

    if (!sendCommandToCore1(initMsg, commandTimeoutMs_)) {
        DEBUG("Core1AudioDelegation: HIBA - Inicializációs parancs küldése sikertelen\n");
        updateState(Core1AudioState::ERROR);
        return false;
    }

    // Válasz várakozása
    if (!waitForCore1Response(commandTimeoutMs_)) {
        DEBUG("Core1AudioDelegation: HIBA - Inicializációs válasz timeout\n");
        updateState(Core1AudioState::ERROR);
        return false;
    }

    updateState(Core1AudioState::READY);
    DEBUG("Core1AudioDelegation: Core1 AudioProcessor sikeresen inicializálva\n");
    return true;
}

/**
 * @brief Core1 AudioProcessor leállítása
 */
bool Core1AudioDelegation::shutdownCore1Audio() {
    DEBUG("Core1AudioDelegation: Core1 AudioProcessor leállítása\n");

    if (currentState_ == Core1AudioState::UNINITIALIZED || currentState_ == Core1AudioState::SHUTDOWN) {
        return true;  // Már leállítva
    }

    if (!sendSimpleCommand(CORE1_AUDIO_CMD_SHUTDOWN)) {
        DEBUG("Core1AudioDelegation: FIGYELEM - Leállítási parancs küldése sikertelen\n");
        // Továbbra is megpróbáljuk leállítani
    }

    updateState(Core1AudioState::SHUTDOWN);
    DEBUG("Core1AudioDelegation: Core1 AudioProcessor leállítva\n");
    return true;
}

/**
 * @brief Audio feldolgozás trigger Core1-en
 */
bool Core1AudioDelegation::triggerAudioProcess(bool collectOsciSamples) {
    if (currentState_ != Core1AudioState::READY) {
        DEBUG("Core1AudioDelegation: HIBA - Nem megfelelő állapot az audio feldolgozáshoz: %d\n", static_cast<int>(currentState_));
        return false;
    }

    updateState(Core1AudioState::PROCESSING);

    uint32_t osciFlag = collectOsciSamples ? 1 : 0;
    Core1AudioMessage processMsg(CORE1_AUDIO_CMD_PROCESS, osciFlag);

    if (!sendCommandToCore1(processMsg, commandTimeoutMs_)) {
        DEBUG("Core1AudioDelegation: HIBA - Audio feldolgozási parancs küldése sikertelen\n");
        updateState(Core1AudioState::ERROR);
        return false;
    }

    // Nem várunk szinkron választ, mivel a feldolgozás aszinkron
    updateState(Core1AudioState::READY);
    return true;
}

/**
 * @brief FFT méret beállítása Core1-en
 */
bool Core1AudioDelegation::setFftSize(uint16_t newFftSize) {
    DEBUG("Core1AudioDelegation: FFT méret beállítása: %d\n", newFftSize);

    if (currentState_ != Core1AudioState::READY) {
        DEBUG("Core1AudioDelegation: HIBA - Nem megfelelő állapot az FFT méret módosításához\n");
        return false;
    }

    return sendSimpleCommand(CORE1_AUDIO_CMD_SET_FFT_SIZE, newFftSize);
}

/**
 * @brief Gain érték beállítása Core1-en
 */
bool Core1AudioDelegation::setGainValue(float gainValue) {
    DEBUG("Core1AudioDelegation: Gain érték beállítása: %.2f\n", gainValue);

    if (currentState_ != Core1AudioState::READY) {
        DEBUG("Core1AudioDelegation: HIBA - Nem megfelelő állapot a gain módosításához\n");
        return false;
    }

    uint32_t gainValueBits = *reinterpret_cast<uint32_t*>(&gainValue);
    return sendSimpleCommand(CORE1_AUDIO_CMD_SET_GAIN, gainValueBits);
}

/**
 * @brief Magnitúdó adatok lekérése Core1-ről
 */
uint16_t Core1AudioDelegation::getMagnitudeData(double* buffer, uint16_t bufferSize) {
    if (!buffer || bufferSize == 0) {
        DEBUG("Core1AudioDelegation: HIBA - Érvénytelen buffer paraméterek\n");
        return 0;
    }

    if (currentState_ != Core1AudioState::READY) {
        DEBUG("Core1AudioDelegation: FIGYELEM - Nem megfelelő állapot az adatlekéréshez\n");
        return 0;
    }

    if (!sendSimpleCommand(CORE1_AUDIO_CMD_GET_MAGNITUDE_DATA, bufferSize)) {
        DEBUG("Core1AudioDelegation: HIBA - Magnitúdó adatlekérési parancs sikertelen\n");
        return 0;
    }

    // Adatok átvétele Core1-ről
    size_t expectedDataSize = bufferSize * sizeof(double);
    if (!transferDataFromCore1(buffer, bufferSize * sizeof(double), expectedDataSize)) {
        DEBUG("Core1AudioDelegation: HIBA - Magnitúdó adatok átvétele sikertelen\n");
        return 0;
    }

    return bufferSize;
}

/**
 * @brief Oszcilloszkóp adatok lekérése Core1-ről
 */
uint16_t Core1AudioDelegation::getOscilloscopeData(int* buffer, uint16_t bufferSize) {
    if (!buffer || bufferSize == 0) {
        DEBUG("Core1AudioDelegation: HIBA - Érvénytelen buffer paraméterek\n");
        return 0;
    }

    if (currentState_ != Core1AudioState::READY) {
        DEBUG("Core1AudioDelegation: FIGYELEM - Nem megfelelő állapot az adatlekéréshez\n");
        return 0;
    }

    if (!sendSimpleCommand(CORE1_AUDIO_CMD_GET_OSCILLOSCOPE_DATA, bufferSize)) {
        DEBUG("Core1AudioDelegation: HIBA - Oszcilloszkóp adatlekérési parancs sikertelen\n");
        return 0;
    }

    // Adatok átvétele Core1-ről
    size_t expectedDataSize = bufferSize * sizeof(int);
    if (!transferDataFromCore1(buffer, bufferSize * sizeof(int), expectedDataSize)) {
        DEBUG("Core1AudioDelegation: HIBA - Oszcilloszkóp adatok átvétele sikertelen\n");
        return 0;
    }

    return bufferSize;
}

/**
 * @brief Core1 AudioProcessor állapot lekérdezése
 */
Core1AudioState Core1AudioDelegation::getCore1AudioState() { return currentState_; }

/**
 * @brief Teljesítménystatisztikák lekérése Core1-ről
 */
Core1AudioPerformanceStats Core1AudioDelegation::getPerformanceStats() {
    Core1AudioPerformanceStats stats;

    if (currentState_ != Core1AudioState::READY) {
        DEBUG("Core1AudioDelegation: FIGYELEM - Nem megfelelő állapot a statisztikák lekéréséhez\n");
        return stats;
    }

    if (!sendSimpleCommand(CORE1_AUDIO_CMD_GET_PERFORMANCE_STATS)) {
        DEBUG("Core1AudioDelegation: HIBA - Teljesítménystatisztika lekérési parancs sikertelen\n");
        return stats;
    }

    // Statisztikák átvétele Core1-ről
    if (!transferDataFromCore1(&stats, sizeof(stats), sizeof(stats))) {
        DEBUG("Core1AudioDelegation: HIBA - Teljesítménystatisztikák átvétele sikertelen\n");
        return Core1AudioPerformanceStats();  // Üres statisztika visszaadása
    }

    lastStats_ = stats;
    return stats;
}

/**
 * @brief Core1 AudioProcessor állapot ellenőrzése és hibajavítás
 */
bool Core1AudioDelegation::checkAndMaintainCore1Audio() {
    // Kommunikációs timeout ellenőrzése
    uint32_t currentTime = millis();
    if (lastCommandTimestamp_ > 0 && (currentTime - lastCommandTimestamp_) > (commandTimeoutMs_ * 2)) {
        DEBUG("Core1AudioDelegation: FIGYELEM - Hosszú inaktivitás, állapot ellenőrzése\n");

        // Állapot lekérdezése
        if (!sendSimpleCommand(CORE1_AUDIO_CMD_GET_STATUS)) {
            DEBUG("Core1AudioDelegation: HIBA - Core1 nem válaszol, hibaállapot\n");
            updateState(Core1AudioState::ERROR);
            return false;
        }
    }

    // Teljesítménystatisztikák ellenőrzése
    Core1AudioPerformanceStats currentStats = getPerformanceStats();
    if (currentStats.errorCount > lastStats_.errorCount) {
        DEBUG("Core1AudioDelegation: FIGYELEM - Core1-en hibák észlelve: %lu\n", currentStats.errorCount);
    }

    return isStateValid();
}

/**
 * @brief Kommunikációs timeout beállítása
 */
void Core1AudioDelegation::setCommandTimeout(uint32_t timeoutMs) {
    commandTimeoutMs_ = timeoutMs;
    DEBUG("Core1AudioDelegation: Parancs timeout beállítva: %lu ms\n", timeoutMs);
}

/**
 * @brief Debug információk kiírása
 */
void Core1AudioDelegation::printDebugInfo() {
    DEBUG("\n========== CORE1 AUDIO DELEGATION STATUS ==========\n");
    DEBUG("Jelenlegi állapot: %d\n", static_cast<int>(currentState_));
    DEBUG("Parancs timeout: %lu ms\n", commandTimeoutMs_);
    DEBUG("Utolsó parancs: %lu ms ezelőtt\n", lastCommandTimestamp_ > 0 ? (millis() - lastCommandTimestamp_) : 0);

    if (lastStats_.lastUpdateTimestamp > 0) {
        DEBUG("--- Teljesítménystatisztikák ---\n");
        DEBUG("Összes process hívás: %llu\n", lastStats_.totalProcessCalls);
        DEBUG("Átlagos feldolgozási idő: %llu us\n", lastStats_.averageProcessTimeMicros);
        DEBUG("Min/Max feldolgozási idő: %llu/%llu us\n", lastStats_.minProcessTimeMicros, lastStats_.maxProcessTimeMicros);
        DEBUG("Memóriahasználat: %lu bytes (%.2f KB)\n", lastStats_.memoryUsageBytes, lastStats_.memoryUsageBytes / 1024.0f);
        DEBUG("CPU használat: %.1f%%\n", lastStats_.currentCpuUsagePercent);
        DEBUG("Hibák száma: %lu\n", lastStats_.errorCount);
    }

    DEBUG("===================================================\n\n");
}

// Privát segédfüggvények implementációja

/**
 * @brief Parancs küldése Core1-nek
 */
bool Core1AudioDelegation::sendCommandToCore1(const Core1AudioMessage& message, uint32_t timeoutMs) {
    if (timeoutMs == 0) timeoutMs = commandTimeoutMs_;

    uint32_t startTime = millis();

    // FIFO elérhetőség ellenőrzése
    while (!rp2040.fifo.push_nb(message.command)) {
        if ((millis() - startTime) > timeoutMs) {
            DEBUG("Core1AudioDelegation: TIMEOUT - FIFO parancs küldése\n");
            return false;
        }
        delay(1);
    }

    // Paraméterek küldése ha szükséges
    if (message.param1 != 0) {
        while (!rp2040.fifo.push_nb(message.param1)) {
            if ((millis() - startTime) > timeoutMs) {
                DEBUG("Core1AudioDelegation: TIMEOUT - FIFO param1 küldése\n");
                return false;
            }
            delay(1);
        }
    }

    if (message.param2 != 0) {
        while (!rp2040.fifo.push_nb(message.param2)) {
            if ((millis() - startTime) > timeoutMs) {
                DEBUG("Core1AudioDelegation: TIMEOUT - FIFO param2 küldése\n");
                return false;
            }
            delay(1);
        }
    }

    if (message.param3 != 0) {
        while (!rp2040.fifo.push_nb(message.param3)) {
            if ((millis() - startTime) > timeoutMs) {
                DEBUG("Core1AudioDelegation: TIMEOUT - FIFO param3 küldése\n");
                return false;
            }
            delay(1);
        }
    }

    lastCommandTimestamp_ = millis();
    return true;
}

/**
 * @brief Core1 válasz várakozása
 */
bool Core1AudioDelegation::waitForCore1Response(uint32_t timeoutMs) {
    if (timeoutMs == 0) timeoutMs = commandTimeoutMs_;

    uint32_t startTime = millis();

    while ((millis() - startTime) < timeoutMs) {
        if (rp2040.fifo.available() > 0) {
            uint32_t response;
            if (rp2040.fifo.pop_nb(&response)) {
                DEBUG("Core1AudioDelegation: Core1 válasz érkezett: 0x%lX\n", response);
                return true;
            }
        }
        delay(1);
    }

    DEBUG("Core1AudioDelegation: TIMEOUT - Core1 válasz várakozása\n");
    return false;
}

/**
 * @brief Egyszerű parancs küldése
 */
bool Core1AudioDelegation::sendSimpleCommand(AudioProcessorCore1Command cmd, uint32_t param1, uint32_t param2, uint32_t param3) {
    Core1AudioMessage message(static_cast<uint32_t>(cmd), param1, param2, param3);
    return sendCommandToCore1(message);
}

/**
 * @brief Adatok átvétele Core1-ről
 */
bool Core1AudioDelegation::transferDataFromCore1(void* buffer, size_t bufferSize, size_t expectedDataSize) {
    if (!buffer || bufferSize < expectedDataSize) {
        DEBUG("Core1AudioDelegation: HIBA - Érvénytelen adatátviteli paraméterek\n");
        return false;
    }

    // Ez egy egyszerűsített implementáció
    // Valós implementációban egy fejlettebb protokollt használnánk
    // pl. chunk-okra bontott adatátvitel FIFO-n keresztül

    DEBUG("Core1AudioDelegation: FIGYELEM - Adatátvitel implementáció hiányos\n");

    // Placeholder implementáció - nullázás
    memset(buffer, 0, expectedDataSize);

    return true;
}

/**
 * @brief Adatok küldése Core1-nek
 */
bool Core1AudioDelegation::transferDataToCore1(const void* data, size_t dataSize) {
    if (!data || dataSize == 0) {
        DEBUG("Core1AudioDelegation: HIBA - Érvénytelen adatküldési paraméterek\n");
        return false;
    }

    // Placeholder implementáció
    DEBUG("Core1AudioDelegation: FIGYELEM - Adatküldés implementáció hiányos\n");

    return true;
}

/**
 * @brief Állapot frissítése
 */
void Core1AudioDelegation::updateState(Core1AudioState newState) {
    if (currentState_ != newState) {
        DEBUG("Core1AudioDelegation: Állapotváltás: %d -> %d\n", static_cast<int>(currentState_), static_cast<int>(newState));
        currentState_ = newState;
    }
}

/**
 * @brief Állapot érvényességének ellenőrzése
 */
bool Core1AudioDelegation::isStateValid() const { return (currentState_ == Core1AudioState::READY || currentState_ == Core1AudioState::PROCESSING); }

/**
 * @brief Kommunikációs hiba kezelése
 */
void Core1AudioDelegation::handleCommunicationError() {
    DEBUG("Core1AudioDelegation: Kommunikációs hiba kezelése\n");
    updateState(Core1AudioState::ERROR);

    // FIFO tisztítása
    while (rp2040.fifo.available() > 0) {
        uint32_t dummy;
        rp2040.fifo.pop_nb(&dummy);
    }
}
