#include "Core1AsyncTaskManager.h"

#include <algorithm>
#include <cstring>

#include "PicoMemoryInfo.h"
#include "pico/stdlib.h"

Core1AsyncTaskManager::Core1AsyncTaskManager(Core1FftProcessor* processor) : initialized_(false), running_(false), nextTaskId_(1), processor_(processor), lastUpdateTime_(0) {
    DEBUG("Core1AsyncTaskManager: Konstruktor\n");

    if (!processor_) {
        DEBUG("Core1AsyncTaskManager: HIBA - Null processor referencia\n");
    }

    // Statisztikák inicializálása
    memset(&stats_, 0, sizeof(stats_));
}

Core1AsyncTaskManager::~Core1AsyncTaskManager() {
    DEBUG("Core1AsyncTaskManager: Destruktor kezdete\n");
    if (initialized_) {
        shutdown();
    }
    DEBUG("Core1AsyncTaskManager: Destruktor vége\n");
}

bool Core1AsyncTaskManager::initialize() {
    DEBUG("Core1AsyncTaskManager: Inicializálás kezdete\n");

    if (initialized_) {
        DEBUG("Core1AsyncTaskManager: Már inicializálva\n");
        return true;
    }

    if (!processor_) {
        DEBUG("Core1AsyncTaskManager: HIBA - Null processor\n");
        return false;
    }

    // Mutex inicializálása
    mutex_init(&taskMutex_);

    // Tárolók inicializálása
    taskQueue_.clear();
    activeTasks_.clear();
    taskQueue_.reserve(MAX_TASK_QUEUE);
    activeTasks_.reserve(MAX_CONCURRENT_TASKS);

    // Statisztikák nullázása
    memset(&stats_, 0, sizeof(stats_));
    stats_.isRunning = true;

    // Timer inicializálása
    lastUpdateTime_ = time_us_32();

    initialized_ = true;
    running_ = true;

    DEBUG("Core1AsyncTaskManager: Inicializálás sikeres\n");
    return true;
}

void Core1AsyncTaskManager::shutdown() {
    DEBUG("Core1AsyncTaskManager: Leállítás kezdete\n");

    if (!initialized_) {
        return;
    }

    running_ = false;

    // Összes feladat törlése
    clearAllTasks();

    initialized_ = false;
    stats_.isRunning = false;

    DEBUG("Core1AsyncTaskManager: Leállítás befejezve\n");
}

uint32_t Core1AsyncTaskManager::submitFFTTask(const float* inputData, uint16_t fftSize, float* outputBuffer, TaskPriority priority,
                                              std::function<void(const FftTask&, bool)> callback, uint32_t timeoutMs, bool applyWindow) {
    if (!running_ || !processor_ || !inputData || !outputBuffer) {
        DEBUG("Core1AsyncTaskManager: HIBA - Érvénytelen paraméterek\n");
        return 0;
    }

    mutex_enter_blocking(&taskMutex_);

    // Queue méret ellenőrzése
    if (taskQueue_.size() >= MAX_TASK_QUEUE) {
        mutex_exit(&taskMutex_);
        DEBUG("Core1AsyncTaskManager: HIBA - Task queue megtelt\n");
        return 0;
    }

    // Új feladat létrehozása
    FftTask task = {};
    task.taskId = generateTaskId();
    task.status = TaskStatus::PENDING;
    task.priority = priority;
    task.fftSize = fftSize;
    task.inputData = inputData;
    task.outputBuffer = outputBuffer;
    task.applyWindow = applyWindow;
    task.submittedTime = time_us_32();
    task.timeoutMs = timeoutMs;
    task.callback = callback;

    // Feladat hozzáadása queue-hoz
    taskQueue_.push_back(task);

    // Prioritás alapú rendezés
    sortTasksByPriority();

    stats_.totalTasks++;
    stats_.queuedTasks = taskQueue_.size();

    uint32_t taskId = task.taskId;

    mutex_exit(&taskMutex_);

    DEBUG("Core1AsyncTaskManager: Feladat beküldve (ID: %lu, FFT: %d)\n", taskId, fftSize);
    return taskId;
}

Core1AsyncTaskManager::TaskStatus Core1AsyncTaskManager::getTaskStatus(uint32_t taskId) {
    mutex_enter_blocking(&taskMutex_);

    FftTask* task = findTask(taskId);
    TaskStatus status = task ? task->status : TaskStatus::FAILED;

    mutex_exit(&taskMutex_);
    return status;
}

bool Core1AsyncTaskManager::getTaskResult(uint32_t taskId, Core1FftProcessor::FftResult& result) {
    mutex_enter_blocking(&taskMutex_);

    FftTask* task = findTask(taskId);
    bool hasResult = false;

    if (task && task->status == TaskStatus::COMPLETED) {
        result = task->result;
        hasResult = true;
    }

    mutex_exit(&taskMutex_);
    return hasResult;
}

bool Core1AsyncTaskManager::cancelTask(uint32_t taskId) {
    mutex_enter_blocking(&taskMutex_);

    // Keresés a queue-ban
    auto it = std::find_if(taskQueue_.begin(), taskQueue_.end(), [taskId](const FftTask& task) { return task.taskId == taskId; });

    if (it != taskQueue_.end() && it->status == TaskStatus::PENDING) {
        taskQueue_.erase(it);
        stats_.queuedTasks = taskQueue_.size();
        mutex_exit(&taskMutex_);
        DEBUG("Core1AsyncTaskManager: Feladat törölve (ID: %lu)\n", taskId);
        return true;
    }

    mutex_exit(&taskMutex_);
    return false;
}

bool Core1AsyncTaskManager::waitForTask(uint32_t taskId, uint32_t timeoutMs) {
    uint32_t startTime = time_us_32();
    uint32_t timeoutUs = timeoutMs * 1000;

    while ((time_us_32() - startTime) < timeoutUs) {
        TaskStatus status = getTaskStatus(taskId);

        if (status == TaskStatus::COMPLETED || status == TaskStatus::FAILED || status == TaskStatus::TIMEOUT) {
            return (status == TaskStatus::COMPLETED);
        }

        // Frissítés és rövid várakozás
        update();
        sleep_ms(5);
    }

    return false;  // Timeout
}

void Core1AsyncTaskManager::update() {
    if (!running_) {
        return;
    }

    uint32_t currentTime = time_us_32();

    // Csak meghatározott időközönként frissítünk
    if ((currentTime - lastUpdateTime_) < (MANAGER_UPDATE_INTERVAL_MS * 1000)) {
        return;
    }

    lastUpdateTime_ = currentTime;

    mutex_enter_blocking(&taskMutex_);

    // 1. Timeout feladatok kezelése
    handleTimeouts();

    // 2. Aktív feladatok ellenőrzése
    checkActiveTasks();

    // 3. Új feladatok indítása
    while (activeTasks_.size() < MAX_CONCURRENT_TASKS && !taskQueue_.empty()) {
        int nextTaskIndex = selectNextTask();
        if (nextTaskIndex >= 0) {
            FftTask task = taskQueue_[nextTaskIndex];
            taskQueue_.erase(taskQueue_.begin() + nextTaskIndex);

            if (startTask(task)) {
                activeTasks_.push_back(task);
            } else {
                // Nem sikerült elindítani, hibás státuszra állítás
                task.status = TaskStatus::FAILED;
                completeTask(task, false);
            }
        } else {
            break;
        }
    }

    // Statisztikák frissítése
    stats_.queuedTasks = taskQueue_.size();
    stats_.activeTasks = activeTasks_.size();

    mutex_exit(&taskMutex_);
}

Core1AsyncTaskManager::ManagerStats Core1AsyncTaskManager::getStats() const {
    mutex_enter_blocking(&taskMutex_);
    ManagerStats stats = stats_;

    // Sikerességi arány számítása
    if (stats.totalTasks > 0) {
        stats.successRate = (float)stats.completedTasks / stats.totalTasks * 100.0f;
    }

    mutex_exit(&taskMutex_);
    return stats;
}

size_t Core1AsyncTaskManager::getActiveTaskCount() const {
    mutex_enter_blocking(&taskMutex_);
    size_t count = activeTasks_.size();
    mutex_exit(&taskMutex_);
    return count;
}

size_t Core1AsyncTaskManager::getQueuedTaskCount() const {
    mutex_enter_blocking(&taskMutex_);
    size_t count = taskQueue_.size();
    mutex_exit(&taskMutex_);
    return count;
}

void Core1AsyncTaskManager::clearAllTasks() {
    mutex_enter_blocking(&taskMutex_);

    // Callback hívása minden feladatra
    for (auto& task : taskQueue_) {
        if (task.callback) {
            task.callback(task, false);
        }
    }

    for (auto& task : activeTasks_) {
        if (task.callback) {
            task.callback(task, false);
        }
    }

    taskQueue_.clear();
    activeTasks_.clear();

    stats_.queuedTasks = 0;
    stats_.activeTasks = 0;

    mutex_exit(&taskMutex_);

    DEBUG("Core1AsyncTaskManager: Összes feladat törölve\n");
}

bool Core1AsyncTaskManager::isProcessorAvailable() const { return processor_ && processor_->isCore1Running(); }

// ============================================================================
// PRIVÁT METÓDUSOK
// ============================================================================

int Core1AsyncTaskManager::selectNextTask() {
    if (taskQueue_.empty()) {
        return -1;
    }

    // Prioritás alapú kiválasztás (már rendezett)
    for (size_t i = 0; i < taskQueue_.size(); i++) {
        if (taskQueue_[i].status == TaskStatus::PENDING) {
            return (int)i;
        }
    }

    return -1;
}

bool Core1AsyncTaskManager::startTask(FftTask& task) {
    if (!processor_ || !processor_->isCore1Running()) {
        DEBUG("Core1AsyncTaskManager: HIBA - Processor nem elérhető\n");
        return false;
    }

    // FFT feldolgozás indítása
    bool success = processor_->processFFTAsync(task.inputData, task.fftSize, task.outputBuffer, task.applyWindow);

    if (success) {
        task.status = TaskStatus::PROCESSING;
        task.startedTime = time_us_32();
        DEBUG("Core1AsyncTaskManager: Feladat elindítva (ID: %lu)\n", task.taskId);
    } else {
        DEBUG("Core1AsyncTaskManager: HIBA - Feladat indítás sikertelen (ID: %lu)\n", task.taskId);
    }

    return success;
}

void Core1AsyncTaskManager::checkActiveTasks() {
    for (auto it = activeTasks_.begin(); it != activeTasks_.end();) {
        if (it->status == TaskStatus::PROCESSING) {
            // Eredmény ellenőrzése
            Core1FftProcessor::FftResult result;
            if (processor_->getResult(result, 0)) {  // Non-blocking check
                it->result = result;
                it->completedTime = time_us_32();
                completeTask(*it, result.success);
                it = activeTasks_.erase(it);
            } else {
                ++it;
            }
        } else {
            ++it;
        }
    }
}

void Core1AsyncTaskManager::handleTimeouts() {
    uint32_t currentTime = time_us_32();

    for (auto it = activeTasks_.begin(); it != activeTasks_.end();) {
        if (it->status == TaskStatus::PROCESSING) {
            uint32_t elapsedMs = (currentTime - it->startedTime) / 1000;

            if (elapsedMs > it->timeoutMs) {
                DEBUG("Core1AsyncTaskManager: Feladat timeout (ID: %lu, %lu ms)\n", it->taskId, elapsedMs);
                it->status = TaskStatus::TIMEOUT;
                completeTask(*it, false);
                it = activeTasks_.erase(it);
            } else {
                ++it;
            }
        } else {
            ++it;
        }
    }
}

void Core1AsyncTaskManager::completeTask(FftTask& task, bool success) {
    if (success) {
        task.status = TaskStatus::COMPLETED;
    } else if (task.status != TaskStatus::TIMEOUT) {
        task.status = TaskStatus::FAILED;
    }

    // Callback hívása
    if (task.callback) {
        task.callback(task, success);
    }

    // Statisztikák frissítése
    updateStats(task, success);

    DEBUG("Core1AsyncTaskManager: Feladat befejezve (ID: %lu, %s)\n", task.taskId, success ? "SIKERES" : "SIKERTELEN");
}

void Core1AsyncTaskManager::removeActiveTask(uint32_t taskId) {
    auto it = std::find_if(activeTasks_.begin(), activeTasks_.end(), [taskId](const FftTask& task) { return task.taskId == taskId; });

    if (it != activeTasks_.end()) {
        activeTasks_.erase(it);
        stats_.activeTasks = activeTasks_.size();
    }
}

Core1AsyncTaskManager::FftTask* Core1AsyncTaskManager::findTask(uint32_t taskId) {
    // Keresés aktív feladatokban
    for (auto& task : activeTasks_) {
        if (task.taskId == taskId) {
            return &task;
        }
    }

    // Keresés queue-ban
    for (auto& task : taskQueue_) {
        if (task.taskId == taskId) {
            return &task;
        }
    }

    return nullptr;
}

void Core1AsyncTaskManager::updateStats(const FftTask& task, bool success) {
    if (success) {
        stats_.completedTasks++;
    } else {
        if (task.status == TaskStatus::TIMEOUT) {
            stats_.timeoutTasks++;
        } else {
            stats_.failedTasks++;
        }
    }

    // Feldolgozási idő frissítése
    if (task.completedTime > task.startedTime) {
        uint32_t processingTimeMs = (task.completedTime - task.startedTime) / 1000;

        if (stats_.completedTasks == 1) {
            stats_.averageProcessingTimeMs = processingTimeMs;
        } else {
            stats_.averageProcessingTimeMs = (stats_.averageProcessingTimeMs * (stats_.completedTasks - 1) + processingTimeMs) / stats_.completedTasks;
        }

        if (processingTimeMs > stats_.maxProcessingTimeMs) {
            stats_.maxProcessingTimeMs = processingTimeMs;
        }
    }
}

void Core1AsyncTaskManager::sortTasksByPriority() {
    std::sort(taskQueue_.begin(), taskQueue_.end(), [](const FftTask& a, const FftTask& b) {
        if (a.priority != b.priority) {
            return a.priority > b.priority;  // Magasabb prioritás előbb
        }
        return a.submittedTime < b.submittedTime;  // FIFO ugyanazon prioritáson belül
    });
}

uint32_t Core1AsyncTaskManager::generateTaskId() {
    uint32_t id = nextTaskId_++;
    if (nextTaskId_ == 0) {  // Overflow kezelése
        nextTaskId_ = 1;
    }
    return id;
}
