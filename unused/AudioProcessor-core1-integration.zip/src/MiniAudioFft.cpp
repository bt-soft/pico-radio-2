#include "MiniAudioFft.h"

#include <cmath>  // std::round, std::max, std::min, std::abs

#include "Config.h"  // Szükséges a config.data eléréséhez
#include "rtVars.h"  // rtv::muteStat eléréséhez

// Konstans a módkijelző láthatósági idejéhez (ms)
constexpr uint32_t MODE_INDICATOR_TIMEOUT_MS = 20000;  // 20 másodperc

#define NUM_BINS(maxX, minX) std::max(1, maxX - minX + 1)

/**
 * @brief A MiniAudioFft komponens konstruktora.
 *
 * Inicializálja a komponenst a megadott pozícióval, méretekkel és a TFT objektummal.
 * Beállítja a kezdeti megjelenítési módot és inicializálja a belső puffereket.
 *
 * @param tft_ref Referencia a TFT_eSPI objektumra, amire a komponens rajzolni fog.
 * @param x A komponens bal felső sarkának X koordinátája a képernyőn.
 * @param y A komponens bal felső sarkának Y koordinátája a képernyőn.
 * @param w A komponens szélessége pixelekben.
 * @param h A komponens magassága pixelekben.
 * @param configuredMaxDisplayAudioFreq Az adott képernyőmódhoz (AM/FM) konfigurált maximális megjelenítendő audio frekvencia.
 * @param configModeField Referencia a Config_t megfelelő uint8_t mezőjére, ahova a módot menteni kell.
 * @param fftGainConfigRef Referencia a Config_t megfelelő float mezőjére az FFT erősítés konfigurációjához.
 * @param targetAudioProcessorSamplingRate Az AudioProcessor számára beállítandó cél mintavételezési frekvencia.
 */
MiniAudioFft::MiniAudioFft(TFT_eSPI& tft, int x, int y, int w, int h, float configuredMaxDisplayAudioFreq, uint8_t& configDisplayModeFieldRef, float& fftGainConfigRef)
    : tft(tft),
      posX(x),
      posY(y),
      width(w),
      height(h),
      currentMode(DisplayMode::Off),                                          // Kezdeti mód (setInitialMode fogja felülírni)
      prevMuteState(rtv::muteStat),                                           // Némítás előző állapotának inicializálása
      modeIndicatorShowUntil(0),                                              // Kezdetben nem látható (setInitialMode állítja)
      isIndicatorCurrentlyVisible(true),                                      // Kezdetben látható (setInitialMode állítja)
      lastTouchProcessTime(0),                                                // Debounce időzítő nullázása
      configModeFieldRef(configDisplayModeFieldRef),                          // Referencia elmentése a kijelzési módhoz
      currentConfiguredMaxDisplayAudioFreqHz(configuredMaxDisplayAudioFreq),  // Maximális frekvencia elmentése
      activeFftGainConfigRef(fftGainConfigRef),                               // Referencia elmentése az erősítés konfigurációhoz
      pAudioProcessor(nullptr),                                               // Inicializáljuk nullptr-rel
      pCore1Integration(nullptr),                                             // Core1 integration inicializálása
      Rpeak{0},                                                               // Peak tömb inicializálása
      sprGraph(&tft),                                                         // Sprite inicializálása a TFT referenciával
      spriteCreated(false),                                                   // Sprite még nincs létrehozva
      highResOffset(0),
      envelope_prev_smoothed_max_val(0.0f),
      indicatorFontHeight_(0),                             // Inicializálás
      currentTuningAidMinFreqHz_(0.0f),                    // Inicializálás
      currentTuningAidMaxFreqHz_(0.0f),                    // Inicializálás
      currentTuningAidType_(TuningAidType::OFF_DECODER) {  // Alapértelmezetten OFF_DECODER
    pAudioProcessor = new AudioProcessor(activeFftGainConfigRef, AUDIO_INPUT_PIN, configuredMaxDisplayAudioFreq * 2.0f, AudioProcessorConstants::DEFAULT_FFT_SAMPLES);

    // Core1 integration inicializálása
    pCore1Integration = new AudioProcessorCore1Integration(pAudioProcessor);
    if (pCore1Integration) {
        // Alapértelmezett konfiguráció beállítása
        AudioProcessorCore1Integration::IntegrationConfig config;
        config.mode = AudioProcessorCore1Integration::ProcessingMode::AUTO_FAILOVER;
        config.enableAutoFallback = true;
        config.core1TimeoutMs = 10;  // 10ms timeout
        config.fallbackThresholdMs = 5;
        config.hybridLoadThreshold = 70;  // 70% load threshold
        config.enablePerformanceMonitoring = true;
        config.enableDetailedLogging = false;  // Nem túl részletes a log-olás

        if (pCore1Integration->initialize(config)) {
            DEBUG("MiniAudioFft: Core1 integration sikeresen inicializálva\n");
        } else {
            DEBUG("MiniAudioFft: Core1 integration inicializálás sikertelen\n");
        }
    }

    // A `wabuf` (vízesés és burkológörbe buffer) inicializálása a komponens tényleges méreteivel.
    // Biztosítjuk, hogy a magasság és szélesség pozitív legyen az átméretezés előtt.
    if (this->height > 0 && this->width > 0) {
        wabuf.resize(this->height, std::vector<uint8_t>(this->width, 0));
    } else {
        DEBUG("MiniAudioFft: Invalid dimensions w=%d, h=%d\n", this->width, this->height);
    }

    // Pufferek nullázása
    memset(Rpeak, 0, sizeof(Rpeak));

    // A módkijelző font magasságának kiszámítása és tárolása
    // Ugyanazokat a beállításokat használjuk, mint a drawModeIndicator-ban
    tft.setFreeFont();
    tft.setTextSize(1);
    indicatorFontHeight_ = tft.fontHeight();
}

/**
 *
 */
MiniAudioFft::~MiniAudioFft() {
    if (spriteCreated) {
        sprGraph.deleteSprite();
    }
    if (pCore1Integration) {
        delete pCore1Integration;
        pCore1Integration = nullptr;
    }
    if (pAudioProcessor) {
        delete pAudioProcessor;
        pAudioProcessor = nullptr;
    }
}

/**
 * @brief Beállítja a komponens kezdeti megjelenítési módját.
 * Ezt a szülő képernyő hívja meg a konstruktor után, a configból kiolvasott értékkel.
 * @param mode A beállítandó DisplayMode.
 */
void MiniAudioFft::setInitialMode(DisplayMode mode) {
    currentMode = mode;
    isIndicatorCurrentlyVisible = true;  // Induláskor mindig látható
    modeIndicatorShowUntil = millis() + MODE_INDICATOR_TIMEOUT_MS;

    if (currentMode == DisplayMode::TuningAid) {
        // Az alapértelmezett currentTuningAidType_ CW_TUNING.
        // Hívjuk meg a setTuningAidType-ot, hogy a frekvenciahatárok beállítódjanak.
        setTuningAidType(currentTuningAidType_);
    }

    manageSpriteForMode(currentMode);  // Sprite előkészítése a kezdeti módhoz
    forceRedraw();                     // Ez gondoskodik a clearArea-ról és a drawModeIndicator-ról
}

/**
 * @brief Kezeli a sprite létrehozását/törlését a megadott módhoz.
 * @param modeToPrepareFor Az a mód, amelyhez a sprite-ot elő kell készíteni.
 */
void MiniAudioFft::manageSpriteForMode(DisplayMode modeToPrepareFor) {
    if (spriteCreated) {  // Ha létezik sprite egy korábbi módból
        sprGraph.deleteSprite();
        spriteCreated = false;
    }
    // Sprite használata Waterfall, TuningAid és Envelope módokhoz
    if (modeToPrepareFor == DisplayMode::Waterfall || modeToPrepareFor == DisplayMode::TuningAid || modeToPrepareFor == DisplayMode::Envelope) {
        int graphH = getGraphHeight();
        if (width > 0 && graphH > 0) {
            sprGraph.setColorDepth(16);  // Vagy 8, ha palettát használsz
            sprGraph.createSprite(width, graphH);
            sprGraph.fillSprite(TFT_BLACK);  // Kezdeti törlés
            spriteCreated = true;
        } else {
            spriteCreated = false;  // Nem lehetett létrehozni
            DEBUG("MiniAudioFft: Sprite creation failed for mode %d (w:%d, graphH:%d)\n", static_cast<int>(modeToPrepareFor), width, graphH);
        }
    }
}

/**
 * @brief Vált a következő megjelenítési módra.
 *
 * Körbejár a rendelkezésre álló módok között (0-tól 5-ig).
 * Módváltáskor törli a komponens területét, kirajzolja az új mód nevét,
 * és reseteli a mód-specifikus puffereket.
 */
void MiniAudioFft::cycleMode() {
    // Az enum értékének növelése és körbejárás
    uint8_t modeValue = static_cast<uint8_t>(currentMode);
    modeValue++;  // Lépés a következő módra

    // Ellenőrizzük, hogy FM módban vagyunk-e (a konfigurált maximális megjelenítendő frekvencia alapján)
    // és hogy a következő mód a TuningAid lenne-e. Ha igen, akkor átugorjuk a TuningAid módot.
    if (currentConfiguredMaxDisplayAudioFreqHz == MiniAudioFftConstants::MAX_DISPLAY_AUDIO_FREQ_FM_HZ && static_cast<DisplayMode>(modeValue) == DisplayMode::TuningAid) {
        modeValue++;  // Ugrás a TuningAid utáni módra
    }

    // Ha túlléptünk az utolsó érvényes módon (TuningAid), akkor visszaugrunk az Off-ra.
    if (modeValue > static_cast<uint8_t>(DisplayMode::TuningAid)) {
        modeValue = static_cast<uint8_t>(DisplayMode::Off);
    }
    currentMode = static_cast<DisplayMode>(modeValue);

    // Új mód mentése a konfigurációba a referencián keresztül
    configModeFieldRef = static_cast<uint8_t>(currentMode);

    // Módkijelző időzítőjének és láthatóságának beállítása
    isIndicatorCurrentlyVisible = true;
    modeIndicatorShowUntil = millis() + MODE_INDICATOR_TIMEOUT_MS;

    // Mód-specifikus pufferek resetelése
    if (currentMode == DisplayMode::SpectrumLowRes || (currentMode != DisplayMode::SpectrumLowRes && Rpeak[0] != 0)) {
        memset(Rpeak, 0, sizeof(Rpeak));
    }

    if (currentMode == DisplayMode::Waterfall || currentMode == DisplayMode::Envelope || currentMode == DisplayMode::TuningAid ||  // TuningAid is használja a wabuf-ot
        (currentMode < DisplayMode::Waterfall && !wabuf.empty() && !wabuf[0].empty() && wabuf[0][0] != 0)) {                       // Ha korábbi módból váltunk, ami nem használta
        for (auto& row : wabuf) std::fill(row.begin(), row.end(), 0);
    }

    if (currentMode == DisplayMode::Envelope || (currentMode != DisplayMode::Envelope && envelope_prev_smoothed_max_val != 0.0f)) {
        envelope_prev_smoothed_max_val = 0.0f;  // Envelope simítási előzmény nullázása
    }
    highResOffset = 0;  // Magas felbontású spektrum eltolásának resetelése

    manageSpriteForMode(currentMode);  // Sprite előkészítése az új módhoz

    forceRedraw();  // Teljes újrarajzolás, ami kezeli a clearArea-t és a drawModeIndicator-t
}

/**
 * @brief Letörli a komponens teljes rajzolási területét feketére, és megrajzolja a keretet.
 * A keret magassága az `isIndicatorCurrentlyVisible` állapottól függ.
 */
void MiniAudioFft::clearArea() {
    constexpr int frameThickness = 1;
    int effectiveH = getEffectiveHeight();

    // 1. Meghatározzuk a komponens maximális lehetséges külső határait
    //    (beleértve a keretet is, amikor a módkijelző látható volt).
    //    Ez a terület lesz feketére törölve, hogy a régi keretmaradványok eltűnjenek.
    int maxOuterX = posX - frameThickness;
    int maxOuterY = posY - frameThickness;
    int maxOuterW = width + (frameThickness * 2);
    int maxOuterH_forClear = height + (frameThickness * 2);  // A komponens maximális magasságát használjuk a törléshez

    // Teljes maximális terület törlése feketére
    tft.fillRect(maxOuterX, maxOuterY, maxOuterW, maxOuterH_forClear, TFT_BLACK);

    // 2. Az ÚJ keret kirajzolása az AKTUÁLIS effektív magasság alapján.
    int currentFrameOuterX = posX - frameThickness;
    int currentFrameOuterY = posY - frameThickness;
    int currentFrameOuterW = width + (frameThickness * 2);
    int currentFrameOuterH_forNewFrame = effectiveH + (frameThickness * 2);  // Keret az aktuális effektív magassághoz

    tft.drawRect(currentFrameOuterX, currentFrameOuterY, currentFrameOuterW, currentFrameOuterH_forNewFrame, TFT_COLOR(80, 80, 80));
}

/**
 * @brief Kiszámítja és visszaadja a módkijelző területének magasságát.
 * Ez a `drawModeIndicator`-ban használt font magasságán és egy kis margón alapul.
 * @return int A módkijelző területének magassága pixelekben.
 */
int MiniAudioFft::getIndicatorAreaHeight() const {
    return indicatorFontHeight_ + 2;  // +2 pixel margó
}

/**
 * @brief Visszaadja a komponens aktuális effektív magasságát,
 * figyelembe véve a módkijelző láthatóságát.
 * @return Az effektív magasság pixelekben.
 */
int MiniAudioFft::getEffectiveHeight() const {
    if (isIndicatorCurrentlyVisible) {
        return height;  // Teljes magasság, ha a kijelző látszik
    } else {
        return height - getIndicatorAreaHeight();  // Csökkentett magasság, ha nem látszik
    }
}

/**
 * @brief Kiszámítja és visszaadja a grafikonok számára ténylegesen rendelkezésre álló magasságot.
 * Ez a komponens teljes magassága mínusz a módkijelzőnek MINDIG fenntartott terület,
 * függetlenül attól, hogy a kijelző éppen látható-e. A grafikonok nem nyúlnak bele ebbe a sávba.
 * @return int A grafikonok rajzolási magassága pixelekben.
 */
int MiniAudioFft::getGraphHeight() const { return height - getIndicatorAreaHeight(); }

/**
 * @brief Kiszámítja és visszaadja a módkijelző területének Y kezdőpozícióját a komponensen belül.
 * Ez mindig a grafikon területe alatt van.
 * @return int A módkijelző Y kezdőpozíciója.
 */
int MiniAudioFft::getIndicatorAreaY() const { return posY + getGraphHeight(); }

/**
 * @brief Kirajzolja az aktuális mód nevét a komponens aljára, a számára fenntartott sávba,
 * de csak akkor, ha az `isIndicatorCurrentlyVisible` igaz.
 */
void MiniAudioFft::drawModeIndicator() {

    if (!isIndicatorCurrentlyVisible) {
        return;
    }

    int indicatorH = getIndicatorAreaHeight();
    int indicatorYstart = getIndicatorAreaY();  // A módkijelző sávjának teteje

    if (width < 20 || indicatorH < 8) return;

    tft.setFreeFont();
    tft.setTextSize(1);
    tft.setTextColor(TFT_YELLOW, TFT_BLACK);  // Háttér fekete, ez törli az előzőt
    tft.setTextDatum(BC_DATUM);               // Alul-középre igazítás

    String modeText = "";
    String gainText = "";
    switch (currentMode) {
        case DisplayMode::Off:
            modeText = "Off";
            break;
        case DisplayMode::SpectrumLowRes:
            modeText = "FFT LowRes";
            break;
        case DisplayMode::SpectrumHighRes:
            modeText = "FFT HighRes";
            break;
        case DisplayMode::Oscilloscope:
            modeText = "Scope";
            break;
        case DisplayMode::Waterfall:
            modeText = "WaterFall";
            break;
        case DisplayMode::Envelope:
            modeText = "Envelope";
            break;
        case DisplayMode::TuningAid:
            if (currentTuningAidType_ == TuningAidType::CW_TUNING) {
                modeText = "Tune CW";
            } else if (currentTuningAidType_ == TuningAidType::RTTY_TUNING) {
                modeText = "Tune RTTY";
            } else {
                modeText = "Tune Off";  // OFF_DECODER state
            }
            break;
        default:
            modeText = "Unknown";
            break;
    }

    // Erősítés állapotának hozzáadása, ha a mód nem "Off"
    if (currentMode != DisplayMode::Off) {
        if (activeFftGainConfigRef == -1.0f) {
            gainText = " (Off)";
        } else if (activeFftGainConfigRef == 0.0f) {
            gainText = " (Auto G)";
        } else if (activeFftGainConfigRef > 0.0f) {
            gainText = " (Manual G)";
        }
    }

    // Módkijelző területének explicit törlése a szövegkirajzolás előtt
    tft.fillRect(posX, indicatorYstart, width, indicatorH, TFT_BLACK);

    // Szöveg kirajzolása a komponens aljára, középre.
    // Az Y koordináta a szöveg alapvonala lesz. A `posY + height - 2` a teljes komponensmagasság aljára igazít.
    tft.drawString(modeText + gainText, posX + width / 2, posY + height - 2);
}

/**
 * @brief A komponens fő ciklusfüggvénye.
 *
 * Kezeli a némítás állapotát, elvégzi az FFT-t (ha szükséges),
 * és kirajzolja az aktuális megjelenítési módot.
 */
void MiniAudioFft::loop() {
    bool needsFullRedrawAfterChecks = false;
    bool muteStateChangedThisLoop = (rtv::muteStat != prevMuteState);
    prevMuteState = rtv::muteStat;

    if (muteStateChangedThisLoop) {
        needsFullRedrawAfterChecks = true;  // Némítás változásakor mindig teljes újrarajzolás
    }

    // Módkijelző láthatóságának időzítő alapú ellenőrzése
    if (isIndicatorCurrentlyVisible && millis() >= modeIndicatorShowUntil) {
        isIndicatorCurrentlyVisible = false;
        needsFullRedrawAfterChecks = true;  // Láthatóság változott, teljes újrarajzolás kell
    }

    if (needsFullRedrawAfterChecks) {
        forceRedraw();  // Ez kezeli a némítást, a módot, és a kijelzőt
        return;         // Ha újrarajzoltunk, ebben a ciklusban nincs több teendő
    }

    // Ha némítva van (és nem most változott az állapota, mert azt már a forceRedraw kezelte)
    if (rtv::muteStat) {
        // A "MUTED" felirat már kint van a forceRedraw miatt, vagy ha a némítás
        // korábban bekapcsolt és azóta nem volt teljes újrarajzolás.
        return;
    }

    // Ha némítva van (és nem most változott az állapota, mert azt már a forceRedraw kezelte)
    if (rtv::muteStat) {
        return;  // A "MUTED" felirat már kint van a forceRedraw miatt
    }

    // Ellenőrizzük az FFT konfigurációt (Disabled, Auto, Manual)
    // Az activeFftGainConfigRef már a megfelelő AM/FM configra mutat.
    // --- ÚJ: "Off" állapot kijelzése a grafikon közepén, ha a módjelző nem látszik ---
    if (currentMode == DisplayMode::Off && !isIndicatorCurrentlyVisible) {
        // A grafikon területét a forceRedraw() már törölte, amikor az isIndicatorCurrentlyVisible false-ra váltott.
        // Vagy egy előző mód rajzolása törölte, mielőtt Off-ra váltottunk.
        drawOffStatusInCenter();
        return;  // Nincs más teendő Off módban, ha a jelző nem látszik.
    }
    // --- ÚJ VÉGE ---
    if (activeFftGainConfigRef == -1.0f) {  // FFT Disabled
        // Ha a módkijelző látható, azt még ki kell rajzolni, de utána return
        // A drawModeIndicator az "Off" szöveget fogja mutatni, ha currentMode == DisplayMode::Off
        // De itt az FFT-t kapcsoltuk ki, a currentMode (pl. SpectrumLowRes) maradhat.
        // A drawModeIndicator-t módosítani kellene, hogy az FFT kikapcsolt állapotát is jelezze,
        // vagy a currentMode-ot DisplayMode::Off-ra állítani, amikor az FFT-t kikapcsoljuk.
        // Egyszerűbb, ha a currentMode-ot állítjuk Off-ra.
        // Ezt a SetupDisplay-nek kellene kezelnie.
        // Jelenleg, ha az FFT config -1.0f, de a currentMode nem Off, akkor is rajzolna.
        return;  // Az "Off" felirat már kint van
    }

    // --- Csak akkor jutunk ide, ha nincs némítás, a mód nem "Off", és nem volt állapotváltozás miatti forceRedraw ---    // Csak akkor végezzük el, ha a kijelzési mód nem Off
    if (currentMode != DisplayMode::Off) {

        // Core1 integrációs réteg használata az AudioProcessor helyett
        if (pCore1Integration && pCore1Integration->isEnabled()) {
            pCore1Integration->process(currentMode == DisplayMode::Oscilloscope);
        } else if (pAudioProcessor) {
            // Fallback az eredeti AudioProcessor-ra, ha a Core1 integráció nem működik
            pAudioProcessor->process(currentMode == DisplayMode::Oscilloscope);
        }
    }

    // Grafikonok kirajzolása a nekik szánt (csökkentett) területre
    // Ezek a függvények a `posY`-tól `posY + getGraphHeight() - 1`-ig rajzolnak.
    // A `getGraphHeight()` mindig a grafikon magasságát adja vissza, a módkijelző sávja nélkül.
    switch (currentMode) {
        // Csak akkor rajzolunk, ha a currentMode nem Off.
        // Az FFT letiltását (-1.0f) a loop elején már kezeltük.
        case DisplayMode::SpectrumLowRes:
            drawSpectrumLowRes();
            break;
        case DisplayMode::SpectrumHighRes:
            drawSpectrumHighRes();
            break;
        case DisplayMode::Oscilloscope:
            drawOscilloscope();
            break;
        case DisplayMode::Waterfall:
            drawWaterfall();
            break;
        case DisplayMode::Envelope:
            drawEnvelope();
            break;
        case DisplayMode::TuningAid:
            drawTuningAid();
            break;
        case DisplayMode::Off:  // Nem csinálunk semmit
        default:
            break;
    }

    // Segédfüggvény a DisplayMode szöveges nevének lekérdezéséhez
    static auto getModeNameString = [](MiniAudioFft::DisplayMode mode) -> const char* {
        switch (mode) {
            case MiniAudioFft::DisplayMode::Off:
                return "Off";
            case MiniAudioFft::DisplayMode::SpectrumLowRes:
                return "LowRes";
            case MiniAudioFft::DisplayMode::SpectrumHighRes:
                return "HighRes";
            case MiniAudioFft::DisplayMode::Oscilloscope:
                return "Scope";
            case MiniAudioFft::DisplayMode::Waterfall:
                return "Waterfall";
            case MiniAudioFft::DisplayMode::Envelope:
                return "Envelope";
            case MiniAudioFft::DisplayMode::TuningAid:
                return "TuneAid";
            default:
                return "Unknown";
        }
    };
}

// Core1 Integration control methods

bool MiniAudioFft::setCore1ProcessingMode(AudioProcessorCore1Integration::ProcessingMode mode) {
    if (pCore1Integration) {
        return pCore1Integration->switchProcessingMode(mode);
    }
    DEBUG("MiniAudioFft: Core1 integration nincs inicializálva - mód váltás sikertelen\n");
    return false;
}

AudioProcessorCore1Integration::IntegrationStats MiniAudioFft::getCore1Stats() const {
    if (pCore1Integration) {
        return pCore1Integration->getStats();
    }
    DEBUG("MiniAudioFft: Core1 integration nincs inicializálva - üres statisztikák\n");
    AudioProcessorCore1Integration::IntegrationStats emptyStats;
    memset(&emptyStats, 0, sizeof(emptyStats));
    return emptyStats;
}

bool MiniAudioFft::isCore1Available() const {
    if (pCore1Integration) {
        return pCore1Integration->isCore1Available();
    }
    return false;
}

void MiniAudioFft::printCore1PerformanceReport() const {
    if (pCore1Integration) {
        pCore1Integration->printPerformanceReport(false);  // Nem részletes jelentés
    } else {
        DEBUG("MiniAudioFft: Core1 integration nincs inicializálva - nincs teljesítmény jelentés\n");
    }
}

/**
 * @brief Érintési események kezelése a komponensen.
 *
 * Ha a komponens területét érintik meg, vált a következő megjelenítési módra
 * és frissíti a kijelzőt.
 *
 * @param touched Igaz, ha éppen érintés történik.
 * @param tx Az érintés X koordinátája.
 * @param ty Az érintés Y koordinátája.
 * @return Igaz, ha az érintést a komponens kezelte, egyébként hamis.
 */
bool MiniAudioFft::handleTouch(bool touched, uint16_t tx, uint16_t ty) {

    if (touched && (tx >= posX && tx < (posX + width) && ty >= posY && ty < (posY + height))) {

        // Debounce logika: Csak akkor dolgozzuk fel, ha elegendő idő telt el az utolsó feldolgozás óta
        if (millis() - lastTouchProcessTime > MiniAudioFftConstants::TOUCH_DEBOUNCE_MS) {
            lastTouchProcessTime = millis();  // Időbélyeg frissítése
            cycleMode();                      // Ez beállítja az isIndicatorCurrentlyVisible-t, a timert, és hívja a forceRedraw-t
            return true;                      // Kezeltük az érintést
        }

        // Ha túl gyorsan jött az érintés, akkor is jelezzük, hogy a komponens területén volt,
        // de nem váltunk módot, hogy más ne kezelje le.
        return true;
    }
    return false;
}

/**
 * @brief Kényszeríti a komponens teljes újrarajzolását az aktuális módban.
 *
 * Letörli a komponenst az effektív magasságának megfelelően, és újrarajzolja a tartalmat.
 */
void MiniAudioFft::forceRedraw() {

    clearArea();  // Ez már az `getEffectiveHeight()`-et használja a kerethez és a törléshez

    if (rtv::muteStat) {
        drawMuted();  // A drawMuted-nek is az effektív magasság közepére kell rajzolnia

    } else if (currentMode == DisplayMode::Off) {

        // Ha a currentMode Off, akkor az FFT configtól függetlenül "Off" jelenik meg.
        drawModeIndicator();  // "Off" kirajzolása (ha látható)

    } else {
        // Ha a currentMode nem Off, de az FFT config Disabled (-1.0f),
        // akkor a performFFT nem csinál semmit, és a rajzoló függvények üres adatot kapnak.
        // Ideális esetben a currentMode-ot Off-ra kellene állítani, ha az FFT config -1.0f.
        // Ezt a SetupDisplay-nek kellene kezelnie.
        // Jelenlegi logika: ha az FFT config -1.0f, de a currentMode nem Off, akkor is rajzolna.
        // A drawModeIndicator továbbra is a currentMode-ot írja ki.

        if (activeFftGainConfigRef != -1.0f) {  // Csak akkor végezzük el az FFT-t és a rajzolást, ha nincs letiltva

            // TuningAid mód használja a nagy felbontású processort, minden más a standard processort
            if (currentMode == DisplayMode::TuningAid) {

                // TuningAid mód: nagy felbontású FFT feldolgozás - Átkapcsolunk ha nem abban vagyunk
                if (pAudioProcessor && pAudioProcessor->getFftSize() != AudioProcessorConstants::HIGH_RES_FFT_SAMPLES) {
                    pAudioProcessor->setFftSize(AudioProcessorConstants::HIGH_RES_FFT_SAMPLES);
                }

            } else {
                // Standard módok: normál FFT feldolgozás - Átkapcsolunk ha nem abban vagyunk
                if (pAudioProcessor && pAudioProcessor->getFftSize() != AudioProcessorConstants::DEFAULT_FFT_SAMPLES) {
                    pAudioProcessor->setFftSize(AudioProcessorConstants::DEFAULT_FFT_SAMPLES);
                }

                if (pAudioProcessor) {
                    pAudioProcessor->process(currentMode == DisplayMode::Oscilloscope);
                }
            }

            switch (currentMode) {
                case DisplayMode::SpectrumLowRes:
                    drawSpectrumLowRes();
                    break;
                case DisplayMode::SpectrumHighRes:
                    drawSpectrumHighRes();
                    break;
                case DisplayMode::Oscilloscope:
                    drawOscilloscope();
                    break;
                case DisplayMode::Waterfall:
                    drawWaterfall();
                    break;
                case DisplayMode::Envelope:
                    drawEnvelope();
                    break;
                case DisplayMode::TuningAid:
                    drawTuningAid();
                    break;
                default:
                    break;  // DisplayMode::Off itt nem fordulhat elő az else ág miatt
            }

        } else {
            // Ha az FFT le van tiltva (-1.0f), de a currentMode nem Off,
            // akkor a grafikon területét törölhetnénk, vagy hagyhatjuk az utolsó állapotot.
            // A clearArea már törölte a hátteret.
            // A performFFT nem futott, RvReal üres vagy régi.
            // A rajzoló függvények nem fognak semmit rajzolni.
        }

        drawModeIndicator();  // És a módkijelző kirajzolása (ha látható)
    }
}

/**
 * @brief Kirajzolja az "Off" státuszt a grafikon területének közepére,
 * ha a komponens Off módban van és a normál módkijelző nem látszik.
 */
void MiniAudioFft::drawOffStatusInCenter() {
    int graphH = getGraphHeight();
    if (width < 10 || graphH < 10) return;  // Nincs elég hely

    // A grafikon területének háttere már fekete kell, hogy legyen
    // a korábbi clearArea() vagy egy másik mód rajzolása miatt.
    // Itt csak a szöveget rajzoljuk ki.

    tft.setTextDatum(MC_DATUM);      // Middle-Center
    tft.setTextColor(TFT_DARKGREY);  // Sötétszürke szín
    tft.setFreeFont();               // Alapértelmezett vagy választott font
    tft.setTextSize(2);              // Megfelelő méret

    int centerX = posX + width / 2;
    int centerY = posY + graphH / 2;
    tft.drawString("Off", centerX, centerY);
}

/**
 * @brief Kirajzolja a "MUTED" szöveget a komponens közepére.
 *
 * Ez a metódus hasonló a drawOffStatusInCenter() metódushoz, de "MUTED" szöveget
 * jelenít meg, amikor a hang némítva van.
 */
void MiniAudioFft::drawMuted() {
    int graphH = getGraphHeight();
    if (width < 10 || graphH < 10) return;  // Nincs elég hely

    // A grafikon területének háttere már fekete kell, hogy legyen
    // a korábbi clearArea() vagy egy másik mód rajzolása miatt.
    // Itt csak a szöveget rajzoljuk ki.

    tft.setTextDatum(MC_DATUM);  // Middle-Center
    tft.setTextColor(TFT_RED);   // Piros szín a figyelemfelhíváshoz
    tft.setFreeFont();           // Alapértelmezett vagy választott font
    tft.setTextSize(2);          // Megfelelő méret

    int centerX = posX + width / 2;
    int centerY = posY + graphH / 2;
    tft.drawString("MUTED", centerX, centerY);
}

/**
 * @brief Hangolást segítő mód kirajzolása.
 *
 * Ez a metódus egy nagy felbontású spektrum analizátort rajzol ki CW és RTTY
 * hangoláshoz. A módtól függően különböző frekvencia tartományt és vonalakat jelenít meg.
 */
void MiniAudioFft::drawTuningAid() {
    using namespace MiniAudioFftConstants;

    int graphH = getGraphHeight();
    if (width == 0 || graphH <= 0) return;
    if (!pAudioProcessor) return;

    // Sprite ellenőrzése és létrehozása szükség esetén
    if (!spriteCreated) {
        DEBUG("MiniAudioFft::drawTuningAid - Sprite not created for TuningAid mode.\n");
        return;
    }

    // Sprite törlése
    sprGraph.fillSprite(TFT_BLACK);

    // FFT adatok és paraméterek beszerzése
    float currentBinWidthHz = pAudioProcessor->getBinWidthHz();
    if (currentBinWidthHz == 0) {
        currentBinWidthHz = (40000.0f / AudioProcessorConstants::DEFAULT_FFT_SAMPLES);
    }

    const uint16_t actualFftSize = pAudioProcessor->getFftSize();

    // Frekvencia tartomány számítása
    float displaySpanHz = currentTuningAidMaxFreqHz_ - currentTuningAidMinFreqHz_;
    if (displaySpanHz <= 0) displaySpanHz = CW_TUNING_AID_SPAN_HZ;

    // Spektrum rajzolása
    for (int x = 0; x < width; ++x) {
        // Pixelhez tartozó frekvencia számítása
        float freq_hz = currentTuningAidMinFreqHz_ + (static_cast<float>(x) / (width - 1)) * displaySpanHz;

        // FFT bin index számítása
        int fft_bin_index = static_cast<int>(std::round(freq_hz / currentBinWidthHz));
        fft_bin_index = constrain(fft_bin_index, 2, static_cast<int>(actualFftSize / 2 - 1));  // FFT adat lekérése
        float magnitude = pAudioProcessor->getMagnitudeData()[fft_bin_index] * TUNING_AID_INPUT_SCALE * activeFftGainConfigRef;

        // Magnitúdó skálázása a grafikon magasságára
        int bar_height = static_cast<int>(magnitude);
        bar_height = constrain(bar_height, 0, graphH - 1);

        // Spektrum vonal rajzolása (alulról felfelé)
        if (bar_height > 0) {
            sprGraph.drawFastVLine(x, graphH - bar_height, bar_height, TFT_YELLOW);
        }
    }

    // Frekvencia referencia vonalak rajzolása a módtól függően
    if (currentTuningAidType_ == TuningAidType::CW_TUNING) {
        // CW mód: egy zöld vonal a cél frekvencián
        float target_freq = config.data.cwReceiverOffsetHz;
        if (target_freq >= currentTuningAidMinFreqHz_ && target_freq <= currentTuningAidMaxFreqHz_) {
            int target_x = static_cast<int>((target_freq - currentTuningAidMinFreqHz_) / displaySpanHz * (width - 1));
            target_x = constrain(target_x, 0, width - 1);
            sprGraph.drawFastVLine(target_x, 0, graphH, TUNING_AID_TARGET_LINE_COLOR);
        }
    } else if (currentTuningAidType_ == TuningAidType::RTTY_TUNING) {
        // RTTY mód: két vonal (mark és space)
        float mark_freq = RTTY_MARKER_FREQUENCY;  // 2295 Hz
        float space_freq = RTTY_SPACE_FREQUENCY;  // 2125 Hz

        // Mark vonal (magenta)
        if (mark_freq >= currentTuningAidMinFreqHz_ && mark_freq <= currentTuningAidMaxFreqHz_) {
            int mark_x = static_cast<int>((mark_freq - currentTuningAidMinFreqHz_) / displaySpanHz * (width - 1));
            mark_x = constrain(mark_x, 0, width - 1);
            sprGraph.drawFastVLine(mark_x, 0, graphH, TUNING_AID_RTTY_MARK_LINE_COLOR);
        }

        // Space vonal (cyan)
        if (space_freq >= currentTuningAidMinFreqHz_ && space_freq <= currentTuningAidMaxFreqHz_) {
            int space_x = static_cast<int>((space_freq - currentTuningAidMinFreqHz_) / displaySpanHz * (width - 1));
            space_x = constrain(space_x, 0, width - 1);
            sprGraph.drawFastVLine(space_x, 0, graphH, TUNING_AID_RTTY_SPACE_LINE_COLOR);
        }
    }
    // OFF_DECODER esetén csak a spektrumot jelenítjük meg vonalak nélkül

    // Sprite kirajzolása a képernyőre
    sprGraph.pushSprite(posX, posY);
}
