#include "AudioProcessorCore1Analysis.h"
#include "PicoMemoryInfo.h"
#include "defines.h"

/**
 * @brief Test program for AudioProcessor Core1 delegation analysis
 * This program runs comprehensive tests to evaluate whether
 * AudioProcessor operations can be effectively delegated to Core1
 */

void runCore1DelegationAnalysisTest() {
    DEBUG("\n");
    DEBUG("================================================================\n");
    DEBUG("         AUDIOPROCESSOR CORE1 DELEGÁLÁS ELEMZÉSI TESZT         \n");
    DEBUG("================================================================\n");
    DEBUG("Teszt kezdete: %lu ms\n", millis());  // Show initial system memory state
    MemoryStatus_t initialMem = getMemoryStatus();
    DEBUG("Kezdeti rendszer memória:\n");
    DEBUG("  Heap használat: %lu bytes (%.2f KB)\n", initialMem.usedHeap, initialMem.usedHeap / 1024.0f);
    DEBUG("  Szabad heap: %lu bytes (%.2f KB)\n", initialMem.freeHeap, initialMem.freeHeap / 1024.0f);
    // Note: Stack usage not available in current MemoryStatus_t structure
    DEBUG("\n");

    // Create analysis instance
    AudioProcessorCore1Analysis analysis;

    // Test 1: Quick feasibility check for different FFT sizes
    DEBUG("=== TESZT 1: Gyors megvalósíthatósági ellenőrzések ===\n");
    uint16_t testSizes[] = {64, 128, 256, 512, 1024, 2048};
    int numTests = sizeof(testSizes) / sizeof(testSizes[0]);

    for (int i = 0; i < numTests; i++) {
        DEBUG("Tesztelés FFT méret: %d\n", testSizes[i]);
        bool feasible = analysis.quickFeasibilityCheck(testSizes[i]);
        DEBUG("Eredmény: %s\n", feasible ? "MEGVALÓSÍTHATÓ" : "NEM AJÁNLOTT");
        DEBUG("---\n");
    }

    // Test 2: Full analysis with detailed benchmark
    DEBUG("\n=== TESZT 2: Teljes elemzés részletes benchmarkkal ===\n");
    AudioProcessorCore1Analysis::AnalysisConfig config;
    config.includeDetailedBenchmark = true;
    config.measureCommOverhead = true;
    config.maxFftSize = 1024;
    config.testIterations = 5;

    DEBUG("Konfigurált elemzési paraméterek:\n");
    DEBUG("  Részletes benchmark: %s\n", config.includeDetailedBenchmark ? "IGEN" : "NEM");
    DEBUG("  Kommunikációs overhead mérés: %s\n", config.measureCommOverhead ? "IGEN" : "NEM");
    DEBUG("  Maximum FFT méret: %d\n", config.maxFftSize);
    DEBUG("  Teszt iterációk: %d\n", config.testIterations);
    DEBUG("\n");

    // Run full analysis
    DEBUG("Teljes elemzés futtatása...\n");
    uint32_t analysisStartTime = millis();

    AudioProcessorCore1Analysis::AnalysisResults results = analysis.performFullAnalysis(config);

    uint32_t analysisEndTime = millis();
    DEBUG("Elemzés futási ideje: %lu ms\n", analysisEndTime - analysisStartTime);

    // Test 3: Print detailed analysis report
    DEBUG("\n=== TESZT 3: Részletes elemzési jelentés ===\n");
    analysis.printAnalysisReport(results);  // Test 4: Memory impact assessment
    DEBUG("\n=== TESZT 4: Memória hatás elemzése ===\n");
    MemoryStatus_t finalMem = getMemoryStatus();
    DEBUG("Végső rendszer memória:\n");
    DEBUG("  Heap használat: %lu bytes (%.2f KB)\n", finalMem.usedHeap, finalMem.usedHeap / 1024.0f);
    DEBUG("  Szabad heap: %lu bytes (%.2f KB)\n", finalMem.freeHeap, finalMem.freeHeap / 1024.0f);
    // Note: Stack usage not available in current MemoryStatus_t structure

    long heapDifference = (long)finalMem.usedHeap - (long)initialMem.usedHeap;

    DEBUG("\nMemória változás:\n");
    DEBUG("  Heap különbség: %ld bytes (%.2f KB)\n", heapDifference, heapDifference / 1024.0f);

    // Test 5: Summary and recommendations
    DEBUG("\n=== TESZT 5: Összefoglaló és ajánlások ===\n");
    DEBUG("DELEGÁLÁS JAVASLAT: %s\n", results.recommendDelegation ? "IGEN - Ajánlott" : "NEM - Nem ajánlott");
    DEBUG("FŐBB INDOKOK:\n");
    DEBUG("  - %s\n", results.reasoningSummary);
    DEBUG("IMPLEMENTÁCIÓS MEGJEGYZÉSEK:\n");
    DEBUG("  - %s\n", results.implementationNotes);
    DEBUG("KOCKÁZATELEMZÉS:\n");
    DEBUG("  - %s\n", results.riskAssessment);

    // Performance summary
    DEBUG("\nTELJESÍTMÉNY ÖSSZEFOGLALÓ:\n");
    if (!results.benchmarkResults.results.empty()) {
        DEBUG("  Benchmark eredmények: %d különböző FFT méret tesztelve\n", (int)results.benchmarkResults.results.size());

        float totalTime = 0;
        for (size_t i = 0; i < results.benchmarkResults.results.size(); i++) {
            totalTime += results.benchmarkResults.results[i].averageProcessTimeMicros;
        }
        float avgTime = totalTime / results.benchmarkResults.results.size();

        DEBUG("  Átlagos feldolgozási idő: %.2f ms\n", avgTime / 1000.0f);
    }
    DEBUG("  Várható teljesítménynyereség: %.1fx (%.1f%%)\n", results.expectedSpeedup, (results.expectedSpeedup - 1.0f) * 100.0f);
    DEBUG("  Kommunikációs hatékonyság: %.1f%%\n", results.commEfficiencyRatio * 100.0f);

    // Memory summary
    DEBUG("\nMEMÓRIA ÖSSZEFOGLALÓ:\n");
    DEBUG("  Core1 memóriaigény: %.2f KB\n", results.core1MemoryRequirement / 1024.0f);
    DEBUG("  Core0 megtakarítás: %.2f KB\n", results.core0MemorySavings / 1024.0f);
    DEBUG("  Megvalósíthatóság: %s\n", results.memoryFeasible ? "MEGFELELŐ" : "PROBLÉMÁS");

    DEBUG("\n================================================================\n");
    DEBUG("            CORE1 DELEGÁLÁS ELEMZÉSI TESZT BEFEJEZVE           \n");
    DEBUG("================================================================\n");
    DEBUG("Teljes teszt futási ideje: %lu ms\n", millis() - analysisStartTime);
    DEBUG("Teszt vége: %lu ms\n", millis());
    DEBUG("\n");
}

/**
 * @brief Quick test for basic Core1 delegation functionality
 * This can be called periodically or during system diagnostics
 */
void runQuickCore1FeasibilityTest() {
    DEBUG("\n=== GYORS CORE1 MEGVALÓSÍTHATÓSÁGI TESZT ===\n");

    AudioProcessorCore1Analysis analysis;

    // Test current typical FFT size (usually 512 or 1024)
    uint16_t currentFftSize = 512;  // This should be taken from actual AudioProcessor config

    DEBUG("Jelenlegi FFT méret tesztelése: %d\n", currentFftSize);
    bool feasible = analysis.quickFeasibilityCheck(currentFftSize);

    DEBUG("\nGYORS ÉRTÉKELÉS EREDMÉNYE:\n");
    DEBUG("Core1 delegálás %d-es FFT-hez: %s\n", currentFftSize, feasible ? "MEGVALÓSÍTHATÓ" : "NEM AJÁNLOTT");

    if (feasible) {
        DEBUG("✓ A Core1 delegálás megvalósítható ezen az FFT méreten\n");
        DEBUG("  További részletes elemzés futtatása ajánlott a teljes értékeléshez\n");
    } else {
        DEBUG("✗ A Core1 delegálás nem ajánlott ezen az FFT méreten\n");
        DEBUG("  Memória vagy kommunikációs korlátok akadályozzák\n");
    }

    DEBUG("=== GYORS TESZT BEFEJEZVE ===\n\n");
}
