#include "Core1FftProcessor.h"

#include <cmath>
#include <cstring>

#include "PicoMemoryInfo.h"
#include "hardware/irq.h"
#include "hardware/timer.h"
#include "pico/multicore.h"
#include "pico/stdlib.h"

// Statikus változók inicializálása
Core1FftProcessor::FftCommand Core1FftProcessor::commandFifo_[COMMAND_FIFO_SIZE];
Core1FftProcessor::FftResult Core1FftProcessor::resultFifo_[RESULT_FIFO_SIZE];
volatile size_t Core1FftProcessor::commandFifoHead_ = 0;
volatile size_t Core1FftProcessor::commandFifoTail_ = 0;
volatile size_t Core1FftProcessor::resultFifoHead_ = 0;
volatile size_t Core1FftProcessor::resultFifoTail_ = 0;
mutex_t Core1FftProcessor::fifoMutex_;
volatile bool Core1FftProcessor::core1Initialized_ = false;
Core1FftProcessor::ProcessorStats Core1FftProcessor::stats_ = {};
float Core1FftProcessor::core1InputBuffer_[MAX_FFT_SIZE];
float Core1FftProcessor::core1OutputBuffer_[MAX_FFT_SIZE];
float Core1FftProcessor::core1WorkingBuffer_[MAX_FFT_SIZE];

Core1FftProcessor::Core1FftProcessor() : initialized_(false), core1Running_(false), shutdownRequested_(false) { DEBUG("Core1FftProcessor: Konstruktor\n"); }

Core1FftProcessor::~Core1FftProcessor() {
    DEBUG("Core1FftProcessor: Destruktor kezdete\n");
    if (initialized_) {
        shutdown();
    }
    DEBUG("Core1FftProcessor: Destruktor vége\n");
}

bool Core1FftProcessor::initialize() {
    DEBUG("Core1FftProcessor: Inicializálás kezdete\n");

    if (initialized_) {
        DEBUG("Core1FftProcessor: Már inicializálva\n");
        return true;
    }

    // Mutex inicializálása
    mutex_init(&fifoMutex_);

    // FIFO-k inicializálása
    initializeFifos();

    // Statisztikák nullázása
    memset(&stats_, 0, sizeof(stats_));
    stats_.isRunning = false;

    // Core1 memória inicializálása
    initializeCore1Memory();

    DEBUG("Core1FftProcessor: Core1 indítása...\n");

    // Core1 indítása
    multicore_launch_core1(core1Main);

    // Várakozás Core1 inicializálására
    uint32_t timeout = time_us_32() + 2000000;  // 2 másodperc timeout
    while (!core1Initialized_ && time_us_32() < timeout) {
        sleep_ms(10);
    }

    if (!core1Initialized_) {
        DEBUG("Core1FftProcessor: HIBA - Core1 inicializálás timeout\n");
        return false;
    }

    // Ping teszt Core1-el
    if (!pingCore1(500)) {
        DEBUG("Core1FftProcessor: HIBA - Core1 ping teszt sikertelen\n");
        return false;
    }

    initialized_ = true;
    core1Running_ = true;
    stats_.isRunning = true;

    DEBUG("Core1FftProcessor: Inicializálás sikeres\n");
    return true;
}

void Core1FftProcessor::shutdown() {
    DEBUG("Core1FftProcessor: Leállítás kezdete\n");

    if (!initialized_) {
        return;
    }

    // Leállítási parancs küldése Core1-nek
    shutdownRequested_ = true;

    FftCommand shutdownCmd = {};
    shutdownCmd.type = CommandType::SHUTDOWN;
    shutdownCmd.timestamp = time_us_32();

    sendCommand(shutdownCmd);

    // Várakozás Core1 leállására
    uint32_t timeout = time_us_32() + 1000000;  // 1 másodperc
    while (core1Running_ && time_us_32() < timeout) {
        sleep_ms(10);
    }

    // Core1 reset (ha szükséges)
    if (core1Running_) {
        DEBUG("Core1FftProcessor: FIGYELEM - Core1 kényszerített leállítás\n");
        multicore_reset_core1();
    }

    initialized_ = false;
    core1Running_ = false;
    stats_.isRunning = false;

    DEBUG("Core1FftProcessor: Leállítás befejezve\n");
}

bool Core1FftProcessor::processFFTAsync(const float* inputData, uint16_t fftSize, float* outputBuffer, bool applyWindow) {
    if (!initialized_ || !core1Running_) {
        DEBUG("Core1FftProcessor: HIBA - Nem inicializált vagy Core1 nem fut\n");
        return false;
    }

    if (fftSize > MAX_FFT_SIZE || !inputData || !outputBuffer) {
        DEBUG("Core1FftProcessor: HIBA - Érvénytelen paraméterek\n");
        return false;
    }

    // Parancs összeállítása
    FftCommand command = {};
    command.type = CommandType::PROCESS_FFT;
    command.fftSize = fftSize;
    command.dataLength = fftSize;
    command.timestamp = time_us_32();
    command.inputData = const_cast<float*>(inputData);
    command.outputData = outputBuffer;
    command.applyWindow = applyWindow;

    return sendCommand(command);
}

bool Core1FftProcessor::getResult(FftResult& result, uint32_t timeoutMs) {
    uint32_t startTime = time_us_32();
    uint32_t timeoutUs = timeoutMs * 1000;

    while ((time_us_32() - startTime) < timeoutUs) {
        if (readResult(result)) {
            return true;
        }
        sleep_us(100);  // Rövid várakozás
    }

    return false;  // Timeout
}

bool Core1FftProcessor::processFFTSync(const float* inputData, uint16_t fftSize, float* outputBuffer, bool applyWindow, uint32_t timeoutMs) {
    // Aszinkron feldolgozás indítása
    if (!processFFTAsync(inputData, fftSize, outputBuffer, applyWindow)) {
        return false;
    }

    // Eredmény várakozás
    FftResult result;
    if (!getResult(result, timeoutMs)) {
        DEBUG("Core1FftProcessor: HIBA - Szinkron feldolgozás timeout\n");
        return false;
    }

    return result.success;
}

Core1FftProcessor::ProcessorStats Core1FftProcessor::getStats() const {
    mutex_enter_blocking(&fifoMutex_);
    ProcessorStats stats = stats_;
    mutex_exit(&fifoMutex_);
    return stats;
}

bool Core1FftProcessor::checkFifoHealth() const {
    // FIFO overflow ellenőrzése
    size_t cmdUsed = (commandFifoHead_ >= commandFifoTail_) ? (commandFifoHead_ - commandFifoTail_) : (COMMAND_FIFO_SIZE - commandFifoTail_ + commandFifoHead_);

    size_t resUsed = (resultFifoHead_ >= resultFifoTail_) ? (resultFifoHead_ - resultFifoTail_) : (RESULT_FIFO_SIZE - resultFifoTail_ + resultFifoHead_);

    return (cmdUsed < COMMAND_FIFO_SIZE - 1) && (resUsed < RESULT_FIFO_SIZE - 1);
}

bool Core1FftProcessor::pingCore1(uint32_t timeoutMs) {
    if (!initialized_) {
        return false;
    }

    FftCommand pingCmd = {};
    pingCmd.type = CommandType::PING;
    pingCmd.timestamp = time_us_32();

    if (!sendCommand(pingCmd)) {
        return false;
    }

    FftResult result;
    if (!getResult(result, timeoutMs)) {
        return false;
    }

    return (result.originalCommand == CommandType::PING) && result.success;
}

bool Core1FftProcessor::changeFFTSize(uint16_t newSize) {
    if (newSize > MAX_FFT_SIZE || newSize < 64) {
        return false;
    }

    FftCommand changeCmd = {};
    changeCmd.type = CommandType::CHANGE_SIZE;
    changeCmd.fftSize = newSize;
    changeCmd.timestamp = time_us_32();

    if (!sendCommand(changeCmd)) {
        return false;
    }

    FftResult result;
    if (!getResult(result, 1000)) {
        return false;
    }

    return result.success;
}

// ============================================================================
// PRIVÁT METÓDUSOK
// ============================================================================

void Core1FftProcessor::core1Main() {
    DEBUG("Core1: Fő loop indítása\n");

    // Core1 inicializálás
    initializeCore1Memory();
    core1Initialized_ = true;

    DEBUG("Core1: Inicializálás kész, várakozás parancsokra\n");

    while (true) {
        // Parancs olvasása
        size_t nextTail = (commandFifoTail_ + 1) % COMMAND_FIFO_SIZE;

        if (nextTail != commandFifoHead_) {
            // Van parancs
            FftCommand command = commandFifo_[commandFifoTail_];
            commandFifoTail_ = nextTail;

            // Leállítás ellenőrzése
            if (command.type == CommandType::SHUTDOWN) {
                DEBUG("Core1: Leállítási parancs fogadva\n");
                break;
            }

            // Parancs végrehajtása
            FftResult result = executeFFT(command);

            // Eredmény küldése vissza
            size_t nextHead = (resultFifoHead_ + 1) % RESULT_FIFO_SIZE;
            if (nextHead != resultFifoTail_) {
                resultFifo_[resultFifoHead_] = result;
                resultFifoHead_ = nextHead;
            } else {
                // Result FIFO overflow
                stats_.fifoOverflows++;
                DEBUG("Core1: FIGYELEM - Result FIFO overflow\n");
            }

            // Statisztikák frissítése
            updateStats(result);
        } else {
            // Nincs parancs, rövid várakozás
            sleep_us(50);
        }
    }

    DEBUG("Core1: Fő loop befejezve\n");
}

Core1FftProcessor::FftResult Core1FftProcessor::executeFFT(const FftCommand& command) {
    FftResult result = {};
    result.originalCommand = command.type;
    result.fftSize = command.fftSize;
    result.timestamp = time_us_32();

    uint32_t startTime = time_us_32();

    switch (command.type) {
        case CommandType::PING:
            result.success = true;
            break;

        case CommandType::CHANGE_SIZE:
            // FFT méret módosítása (jelenleg csak validálás)
            result.success = (command.fftSize >= 64 && command.fftSize <= MAX_FFT_SIZE);
            break;

        case CommandType::PROCESS_FFT: {
            // FFT feldolgozás
            if (!command.inputData || !command.outputData || command.fftSize > MAX_FFT_SIZE) {
                result.success = false;
                result.errorCode = 1;  // Invalid parameters
                break;
            }

            // Adatok másolása Core1 memóriába
            memcpy(core1InputBuffer_, command.inputData, command.dataLength * sizeof(float));

            // Windowing alkalmazása ha szükséges
            if (command.applyWindow) {
                applyHammingWindow(core1InputBuffer_, command.fftSize);
            }

            // FFT számítás (egyszerűsített implementáció)
            // Itt egy valódi FFT library-t kellene használni (pl. CMSIS DSP)
            // Most csak egy dummy implementáció a teszteléshez
            for (uint16_t i = 0; i < command.fftSize / 2; i++) {
                float real = core1InputBuffer_[i * 2];
                float imag = (i * 2 + 1 < command.fftSize) ? core1InputBuffer_[i * 2 + 1] : 0.0f;
                core1OutputBuffer_[i] = sqrtf(real * real + imag * imag);
            }

            // Eredmények másolása vissza
            memcpy(command.outputData, core1OutputBuffer_, (command.fftSize / 2) * sizeof(float));

            result.processedSamples = command.fftSize;
            result.success = true;
            break;
        }

        default:
            result.success = false;
            result.errorCode = 2;  // Unknown command
            break;
    }

    result.processingTimeMicros = time_us_32() - startTime;
    return result;
}

bool Core1FftProcessor::sendCommand(const FftCommand& command) {
    mutex_enter_blocking(&fifoMutex_);

    size_t nextHead = (commandFifoHead_ + 1) % COMMAND_FIFO_SIZE;

    if (nextHead == commandFifoTail_) {
        // FIFO overflow
        mutex_exit(&fifoMutex_);
        stats_.fifoOverflows++;
        DEBUG("Core1FftProcessor: HIBA - Command FIFO overflow\n");
        return false;
    }

    commandFifo_[commandFifoHead_] = command;
    commandFifoHead_ = nextHead;

    mutex_exit(&fifoMutex_);
    return true;
}

bool Core1FftProcessor::readResult(FftResult& result) {
    mutex_enter_blocking(&fifoMutex_);

    size_t nextTail = (resultFifoTail_ + 1) % RESULT_FIFO_SIZE;

    if (nextTail == resultFifoHead_) {
        // Nincs eredmény
        mutex_exit(&fifoMutex_);
        return false;
    }

    result = resultFifo_[resultFifoTail_];
    resultFifoTail_ = nextTail;

    mutex_exit(&fifoMutex_);
    return true;
}

void Core1FftProcessor::handleFifoOverflow() {
    DEBUG("Core1FftProcessor: FIFO overflow kezelése\n");

    // FIFO-k újrainicializálása
    mutex_enter_blocking(&fifoMutex_);
    initializeFifos();
    stats_.fifoOverflows++;
    mutex_exit(&fifoMutex_);
}

void Core1FftProcessor::applyHammingWindow(float* data, size_t size) {
    for (size_t i = 0; i < size; i++) {
        float window = 0.54f - 0.46f * cosf(2.0f * M_PI * i / (size - 1));
        data[i] *= window;
    }
}

void Core1FftProcessor::updateStats(const FftResult& result) {
    mutex_enter_blocking(&fifoMutex_);

    stats_.totalCommands++;
    if (result.success) {
        stats_.successfulCommands++;
    } else {
        stats_.failedCommands++;
    }

    // Átlagos feldolgozási idő frissítése
    if (stats_.totalCommands == 1) {
        stats_.averageProcessingTimeMicros = result.processingTimeMicros;
    } else {
        stats_.averageProcessingTimeMicros = (stats_.averageProcessingTimeMicros * (stats_.totalCommands - 1) + result.processingTimeMicros) / stats_.totalCommands;
    }

    // Maximális feldolgozási idő
    if (result.processingTimeMicros > stats_.maxProcessingTimeMicros) {
        stats_.maxProcessingTimeMicros = result.processingTimeMicros;
    }

    // CPU terhelés becslése (egyszerűsített)
    stats_.currentLoad = (result.processingTimeMicros > 1000) ? std::min(100, (int)(result.processingTimeMicros / 1000)) : 0;

    stats_.lastCommandTimestamp = result.timestamp;

    mutex_exit(&fifoMutex_);
}

void Core1FftProcessor::initializeCore1Memory() {
    // Pufferek nullázása
    memset(core1InputBuffer_, 0, sizeof(core1InputBuffer_));
    memset(core1OutputBuffer_, 0, sizeof(core1OutputBuffer_));
    memset(core1WorkingBuffer_, 0, sizeof(core1WorkingBuffer_));
}

void Core1FftProcessor::initializeFifos() {
    memset(commandFifo_, 0, sizeof(commandFifo_));
    memset(resultFifo_, 0, sizeof(resultFifo_));
    commandFifoHead_ = 0;
    commandFifoTail_ = 0;
    resultFifoHead_ = 0;
    resultFifoTail_ = 0;
}
