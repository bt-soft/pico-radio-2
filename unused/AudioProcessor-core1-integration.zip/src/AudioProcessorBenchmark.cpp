#include "AudioProcessorBenchmark.h"

#include <pico/time.h>

#include "AudioProcessor.h"
#include "PicoMemoryInfo.h"
#include "defines.h"

/**
 * @brief AudioProcessor teljesítménybenchmark osztály - Core1 delegálhatóság értékeléséhez
 */

AudioProcessorBenchmark::AudioProcessorBenchmark() : lastMemoryUsage(0) {}

AudioProcessorBenchmark::~AudioProcessorBenchmark() {}

/**
 * @brief Részletes teljesítménymérés az AudioProcessor process() függvényére
 * @param fftSize FFT méret a teszteléshez
 * @param iterations Iterációk száma az átlagoláshoz
 * @return BenchmarkResult struktúra az eredményekkel
 */
AudioProcessorBenchmark::BenchmarkResult AudioProcessorBenchmark::benchmarkProcessFunction(uint16_t fftSize, int iterations) {
    BenchmarkResult result;
    result.fftSize = fftSize;
    result.iterations = iterations;
    result.success = false;

    // Dummy gain referencia
    float dummyGain = 1.0f;

    // AudioProcessor példányosítása
    AudioProcessor* processor = new AudioProcessor(dummyGain, AUDIO_INPUT_PIN, 30000.0, fftSize);
    if (!processor) {
        DEBUG("AudioProcessorBenchmark: HIBA - AudioProcessor létrehozása sikertelen!\n");
        return result;
    }  // Memóriahasználat mérése allokálás után
    MemoryStatus_t memStatus = getMemoryStatus();
    uint32_t memoryAfterAllocation = memStatus.usedHeap;
    result.memoryUsageBytes = memoryAfterAllocation - lastMemoryUsage;
    lastMemoryUsage = memoryAfterAllocation;

    DEBUG("AudioProcessorBenchmark: FFT méret %d, Memóriahasználat: %lu bytes\n", fftSize, result.memoryUsageBytes);

    // Időmérés inicializálása
    uint64_t totalProcessTime = 0;
    uint64_t minProcessTime = UINT64_MAX;
    uint64_t maxProcessTime = 0;

    uint64_t totalSamplingTime = 0;
    uint64_t totalFftTime = 0;

    bool hasValidMeasurements = false;

    // Benchmark iterációk végrehajtása
    for (int i = 0; i < iterations; i++) {
        // Teljes process() függvény időmérése
        uint64_t startTime = time_us_64();

        processor->process(true);  // Oszcilloszkóp mintagyűjtéssel

        uint64_t endTime = time_us_64();
        uint64_t processTime = endTime - startTime;

        // Statisztikák frissítése
        totalProcessTime += processTime;
        if (processTime < minProcessTime) minProcessTime = processTime;
        if (processTime > maxProcessTime) maxProcessTime = processTime;

        hasValidMeasurements = true;

        // Rövid szünet az iterációk között
        sleep_ms(10);
    }

    if (hasValidMeasurements) {
        result.averageProcessTimeMicros = totalProcessTime / iterations;
        result.minProcessTimeMicros = minProcessTime;
        result.maxProcessTimeMicros = maxProcessTime;
        result.success = true;

        // CPU használat becslése (%)
        // Feltételezzük, hogy a process() függvényt ~30 Hz-cel hívjuk meg
        float processCallFrequency = 30.0f;                            // Hz
        float totalCpuTimeMicros = 1000000.0f / processCallFrequency;  // Rendelkezésre álló idő
        result.estimatedCpuUsagePercent = (result.averageProcessTimeMicros / totalCpuTimeMicros) * 100.0f;

        DEBUG("AudioProcessorBenchmark: FFT %d - Átlag: %llu us, Min: %llu us, Max: %llu us, CPU: %.1f%%\n", fftSize, result.averageProcessTimeMicros, result.minProcessTimeMicros,
              result.maxProcessTimeMicros, result.estimatedCpuUsagePercent);
    }

    // Cleanup
    delete processor;

    return result;
}

/**
 * @brief Teljes benchmark sorozat futtatása különböző FFT méretekkel
 */
AudioProcessorBenchmark::FullBenchmarkResults AudioProcessorBenchmark::runFullBenchmark() {
    FullBenchmarkResults results;

    DEBUG("AudioProcessorBenchmark: Teljes benchmark sorozat indítása...\n");  // Kezdeti memóriaállapot mérése
    MemoryStatus_t memStatus = getMemoryStatus();
    lastMemoryUsage = memStatus.usedHeap;
    DEBUG("AudioProcessorBenchmark: Kezdeti memóriahasználat: %lu bytes\n", lastMemoryUsage);

    // Különböző FFT méretek tesztelése
    uint16_t fftSizes[] = {64, 128, 256, 512, 1024, 2048};
    const int numSizes = sizeof(fftSizes) / sizeof(fftSizes[0]);
    const int iterations = 20;  // 20 iteráció az átlagoláshoz

    for (int i = 0; i < numSizes; i++) {
        uint16_t fftSize = fftSizes[i];

        DEBUG("AudioProcessorBenchmark: Tesztelés FFT méret: %d\n", fftSize);

        BenchmarkResult result = benchmarkProcessFunction(fftSize, iterations);

        if (result.success) {
            results.results.push_back(result);

            // Legjobb és legrosszabb eredmények követése
            if (results.bestPerformance.fftSize == 0 || result.averageProcessTimeMicros < results.bestPerformance.averageProcessTimeMicros) {
                results.bestPerformance = result;
            }

            if (results.worstPerformance.fftSize == 0 || result.averageProcessTimeMicros > results.worstPerformance.averageProcessTimeMicros) {
                results.worstPerformance = result;
            }
        } else {
            DEBUG("AudioProcessorBenchmark: HIBA - FFT méret %d tesztelése sikertelen!\n", fftSize);
        }

        // Garbage collection és memória stabilizálás
        delay(100);
    }

    // Összesített statisztikák számítása
    if (!results.results.empty()) {
        uint64_t totalTime = 0;
        uint32_t totalMemory = 0;
        float totalCpu = 0.0f;

        for (const auto& result : results.results) {
            totalTime += result.averageProcessTimeMicros;
            totalMemory += result.memoryUsageBytes;
            totalCpu += result.estimatedCpuUsagePercent;
        }

        results.averageProcessTime = totalTime / results.results.size();
        results.totalMemoryUsage = totalMemory;
        results.averageCpuUsage = totalCpu / results.results.size();

        DEBUG("AudioProcessorBenchmark: Összegzés - Átlag idő: %llu us, Összes memória: %lu bytes, Átlag CPU: %.1f%%\n", results.averageProcessTime, results.totalMemoryUsage,
              results.averageCpuUsage);
    }

    return results;
}

/**
 * @brief Core1 delegálhatóság értékelése a benchmark eredmények alapján
 */
AudioProcessorBenchmark::Core1DelegationAnalysis AudioProcessorBenchmark::analyzeCore1Delegation(const FullBenchmarkResults& benchmarkResults) {

    Core1DelegationAnalysis analysis;
    analysis.isRecommended = false;
    analysis.recommendedFftSize = 0;
    analysis.estimatedCore1CpuUsage = 0.0f;
    analysis.estimatedMemoryOverhead = 0;

    DEBUG("AudioProcessorBenchmark: Core1 delegálhatóság elemzése...\n");

    if (benchmarkResults.results.empty()) {
        analysis.reasons.push_back("Nincs érvényes benchmark adat");
        return analysis;
    }

    // Kritériumok a Core1 delegáláshoz:
    // 1. CPU használat < 50% (elegendő tartalék)
    // 2. Memóriahasználat < 64KB (biztonságos)
    // 3. Determinisztikus időzítés (max-min < 30% átlagból)

    for (const auto& result : benchmarkResults.results) {
        bool cpuOk = result.estimatedCpuUsagePercent < 50.0f;
        bool memoryOk = result.memoryUsageBytes < 65536;  // 64KB

        // Időzítés konzisztencia ellenőrzése
        uint64_t timingVariation = result.maxProcessTimeMicros - result.minProcessTimeMicros;
        float variationPercent = (timingVariation * 100.0f) / result.averageProcessTimeMicros;
        bool timingOk = variationPercent < 30.0f;

        if (cpuOk && memoryOk && timingOk) {
            analysis.isRecommended = true;
            if (analysis.recommendedFftSize == 0 || result.fftSize > analysis.recommendedFftSize) {
                analysis.recommendedFftSize = result.fftSize;
                analysis.estimatedCore1CpuUsage = result.estimatedCpuUsagePercent;
                analysis.estimatedMemoryOverhead = result.memoryUsageBytes;
            }
        }

        // Részletes indokok gyűjtése
        char reasonBuffer[200];
        snprintf(reasonBuffer, sizeof(reasonBuffer), "FFT %d: CPU %.1f%% (%s), Memória %lu bytes (%s), Időzítés variáció %.1f%% (%s)", result.fftSize,
                 result.estimatedCpuUsagePercent, cpuOk ? "OK" : "MAGAS", result.memoryUsageBytes, memoryOk ? "OK" : "MAGAS", variationPercent, timingOk ? "OK" : "INSTABIL");
        analysis.reasons.push_back(std::string(reasonBuffer));
    }

    // Kommunikációs overhead becslése
    analysis.estimatedFifoOverheadMicros = 50;   // Tapasztalati érték FIFO műveletekhez
    analysis.estimatedSyncOverheadMicros = 100;  // Szinkronizációs overhead

    // Végső ajánlás
    if (analysis.isRecommended) {
        analysis.reasons.push_back("AJÁNLOTT: Core1 delegálás megvalósítható");
        DEBUG("AudioProcessorBenchmark: AJÁNLÁS - Core1 delegálás javasolt FFT méret %d-del\n", analysis.recommendedFftSize);
    } else {
        analysis.reasons.push_back("NEM AJÁNLOTT: Teljesítmény vagy memória korlátok miatt");
        DEBUG("AudioProcessorBenchmark: FIGYELEM - Core1 delegálás nem javasolt\n");
    }

    return analysis;
}

/**
 * @brief Benchmark eredmények kiírása részletes formában
 */
void AudioProcessorBenchmark::printDetailedResults(const FullBenchmarkResults& results) {
    DEBUG("\n========== AUDIOPROCESSOR TELJESÍTMÉNY BENCHMARK ==========\n");
    DEBUG("Összesen %zu különböző FFT méret tesztelve\n", results.results.size());
    DEBUG("Átlagos feldolgozási idő: %llu mikroszekundum\n", results.averageProcessTime);
    DEBUG("Összes memóriahasználat: %lu bytes (%.2f KB)\n", results.totalMemoryUsage, results.totalMemoryUsage / 1024.0f);
    DEBUG("Átlagos CPU használat: %.1f%%\n", results.averageCpuUsage);

    DEBUG("\n--- RÉSZLETES EREDMÉNYEK FFT MÉRETENKÉNT ---\n");
    for (const auto& result : results.results) {
        DEBUG("FFT %d: Idő %llu us (min %llu, max %llu), Memória %lu bytes, CPU %.1f%%\n", result.fftSize, result.averageProcessTimeMicros, result.minProcessTimeMicros,
              result.maxProcessTimeMicros, result.memoryUsageBytes, result.estimatedCpuUsagePercent);
    }

    if (results.bestPerformance.fftSize > 0) {
        DEBUG("\n--- LEGJOBB TELJESÍTMÉNY ---\n");
        DEBUG("FFT %d: %llu us, %.1f%% CPU\n", results.bestPerformance.fftSize, results.bestPerformance.averageProcessTimeMicros, results.bestPerformance.estimatedCpuUsagePercent);
    }

    if (results.worstPerformance.fftSize > 0) {
        DEBUG("\n--- LEGROSSZABB TELJESÍTMÉNY ---\n");
        DEBUG("FFT %d: %llu us, %.1f%% CPU\n", results.worstPerformance.fftSize, results.worstPerformance.averageProcessTimeMicros,
              results.worstPerformance.estimatedCpuUsagePercent);
    }

    DEBUG("=========================================================\n\n");
}

/**
 * @brief Core1 delegálási elemzés eredményeinek kiírása
 */
void AudioProcessorBenchmark::printCore1Analysis(const Core1DelegationAnalysis& analysis) {
    DEBUG("\n========== CORE1 DELEGÁLHATÓSÁG ELEMZÉSE ==========\n");
    DEBUG("Ajánlás: %s\n", analysis.isRecommended ? "DELEGÁLHATÓ" : "NEM DELEGÁLHATÓ");

    if (analysis.isRecommended) {
        DEBUG("Javasolt FFT méret: %d\n", analysis.recommendedFftSize);
        DEBUG("Becsült Core1 CPU használat: %.1f%%\n", analysis.estimatedCore1CpuUsage);
        DEBUG("Becsült memória overhead: %lu bytes (%.2f KB)\n", analysis.estimatedMemoryOverhead, analysis.estimatedMemoryOverhead / 1024.0f);
        DEBUG("FIFO kommunikációs overhead: %lu us\n", analysis.estimatedFifoOverheadMicros);
        DEBUG("Szinkronizációs overhead: %lu us\n", analysis.estimatedSyncOverheadMicros);
    }

    DEBUG("\n--- RÉSZLETES INDOKOK ---\n");
    for (const auto& reason : analysis.reasons) {
        DEBUG("%s\n", reason.c_str());
    }

    DEBUG("================================================\n\n");
}
