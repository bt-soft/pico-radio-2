#pragma once

#include <stdint.h>

#include <functional>
#include <vector>

#include "Core1FftProcessor.h"
#include "defines.h"
#include "pico/mutex.h"

/**
 * @brief Aszinkron feladat kezelő Core1 delegáláshoz
 *
 * Ez az osztály kezeli az AudioProcessor és Core1FftProcessor közötti
 * aszinkron kommunikációt, feladat ütemezést és eredmény kezelést.
 */
class Core1AsyncTaskManager {
   public:
    /**
     * @brief Feladat státusz típusok
     */
    enum class TaskStatus : uint8_t {
        PENDING = 0,     // Várakozik végrehajtásra
        PROCESSING = 1,  // Feldolgozás alatt
        COMPLETED = 2,   // Sikeresen befejezve
        FAILED = 3,      // Hiba történt
        TIMEOUT = 4      // Időtúllépés
    };

    /**
     * @brief Feladat prioritás szintek
     */
    enum class TaskPriority : uint8_t { LOW = 0, NORMAL = 1, HIGH = 2, CRITICAL = 3 };

    /**
     * @brief FFT feldolgozási feladat
     */
    struct FftTask {
        uint32_t taskId;
        TaskStatus status;
        TaskPriority priority;
        uint16_t fftSize;
        const float* inputData;
        float* outputBuffer;
        bool applyWindow;
        uint32_t submittedTime;
        uint32_t startedTime;
        uint32_t completedTime;
        uint32_t timeoutMs;
        std::function<void(const FftTask&, bool)> callback;
        Core1FftProcessor::FftResult result;
    };

    /**
     * @brief Task manager statisztikák
     */
    struct ManagerStats {
        uint32_t totalTasks;
        uint32_t completedTasks;
        uint32_t failedTasks;
        uint32_t timeoutTasks;
        uint32_t averageProcessingTimeMs;
        uint32_t maxProcessingTimeMs;
        uint32_t queuedTasks;
        uint32_t activeTasks;
        float successRate;
        bool isRunning;
    };

   private:
    static constexpr size_t MAX_CONCURRENT_TASKS = 4;
    static constexpr size_t MAX_TASK_QUEUE = 16;
    static constexpr uint32_t DEFAULT_TIMEOUT_MS = 1000;
    static constexpr uint32_t MANAGER_UPDATE_INTERVAL_MS = 10;

    // Manager állapot
    bool initialized_;
    bool running_;
    uint32_t nextTaskId_;

    // Core1 processor referencia
    Core1FftProcessor* processor_;  // Feladat kezelés
    std::vector<FftTask> taskQueue_;
    std::vector<FftTask> activeTasks_;
    mutable mutex_t taskMutex_;

    // Statisztikák
    ManagerStats stats_;

    // Timer kezelés
    uint32_t lastUpdateTime_;

   public:
    /**
     * @brief Konstruktor
     * @param processor Core1FftProcessor referencia
     */
    explicit Core1AsyncTaskManager(Core1FftProcessor* processor);

    /**
     * @brief Destruktor
     */
    ~Core1AsyncTaskManager();

    /**
     * @brief Manager inicializálása
     * @return true ha sikeres
     */
    bool initialize();

    /**
     * @brief Manager leállítása
     */
    void shutdown();

    /**
     * @brief FFT feladat beküldése aszinkron feldolgozásra
     * @param inputData Bemeneti audio adatok
     * @param fftSize FFT méret
     * @param outputBuffer Kimeneti buffer
     * @param priority Feladat prioritás
     * @param callback Callback függvény (opcionális)
     * @param timeoutMs Timeout milliszekundumban
     * @param applyWindow Ablakfüggvény alkalmazása
     * @return Feladat ID, 0 ha hiba
     */
    uint32_t submitFFTTask(const float* inputData, uint16_t fftSize, float* outputBuffer, TaskPriority priority = TaskPriority::NORMAL,
                           std::function<void(const FftTask&, bool)> callback = nullptr, uint32_t timeoutMs = DEFAULT_TIMEOUT_MS, bool applyWindow = true);

    /**
     * @brief Feladat állapotának lekérdezése
     * @param taskId Feladat ID
     * @return Feladat státusz
     */
    TaskStatus getTaskStatus(uint32_t taskId);

    /**
     * @brief Feladat eredményének lekérése
     * @param taskId Feladat ID
     * @param result Eredmény struktúra
     * @return true ha sikeres és van eredmény
     */
    bool getTaskResult(uint32_t taskId, Core1FftProcessor::FftResult& result);

    /**
     * @brief Feladat törlése (ha még nem kezdődött el)
     * @param taskId Feladat ID
     * @return true ha sikeresen törölve
     */
    bool cancelTask(uint32_t taskId);

    /**
     * @brief Várakozás feladat befejezésére
     * @param taskId Feladat ID
     * @param timeoutMs Timeout milliszekundumban
     * @return true ha befejezett, false ha timeout
     */
    bool waitForTask(uint32_t taskId, uint32_t timeoutMs = DEFAULT_TIMEOUT_MS);

    /**
     * @brief Manager frissítése (fő loop-ból hívandó)
     * Ez kezeli a feladat ütemezést és eredmény feldolgozást
     */
    void update();

    /**
     * @brief Manager statisztikák lekérése
     * @return Statisztikák struktúra
     */
    ManagerStats getStats() const;

    /**
     * @brief Aktív feladatok számának lekérése
     * @return Aktív feladatok száma
     */
    size_t getActiveTaskCount() const;

    /**
     * @brief Várakozó feladatok számának lekérése
     * @return Várakozó feladatok száma
     */
    size_t getQueuedTaskCount() const;

    /**
     * @brief Manager futásának ellenőrzése
     * @return true ha fut
     */
    bool isRunning() const { return running_; }

    /**
     * @brief Összes feladat törlése
     */
    void clearAllTasks();

    /**
     * @brief Core1 processor állapotának ellenőrzése
     * @return true ha processor elérhető
     */
    bool isProcessorAvailable() const;

   private:
    /**
     * @brief Következő feladat kiválasztása végrehajtásra
     * @return Feladat index a queue-ban, vagy -1 ha nincs
     */
    int selectNextTask();

    /**
     * @brief Feladat indítása Core1-en
     * @param task Feladat referencia
     * @return true ha sikeresen elindítva
     */
    bool startTask(FftTask& task);

    /**
     * @brief Aktív feladatok ellenőrzése és befejezése
     */
    void checkActiveTasks();

    /**
     * @brief Timeout feladatok kezelése
     */
    void handleTimeouts();

    /**
     * @brief Feladat befejezése és callback hívása
     * @param task Feladat referencia
     * @param success Sikeres volt-e
     */
    void completeTask(FftTask& task, bool success);

    /**
     * @brief Feladat törlése aktív listából
     * @param taskId Feladat ID
     */
    void removeActiveTask(uint32_t taskId);

    /**
     * @brief Feladat keresése ID alapján
     * @param taskId Feladat ID
     * @return Feladat pointer vagy nullptr
     */
    FftTask* findTask(uint32_t taskId);

    /**
     * @brief Statisztikák frissítése
     * @param task Befejezett feladat
     * @param success Sikeres volt-e
     */
    void updateStats(const FftTask& task, bool success);

    /**
     * @brief Prioritás alapú rendezés
     */
    void sortTasksByPriority();

    /**
     * @brief Következő feladat ID generálása
     * @return Új feladat ID
     */
    uint32_t generateTaskId();
};
