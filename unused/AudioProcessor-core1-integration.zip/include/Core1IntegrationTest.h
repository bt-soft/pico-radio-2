#pragma once

/**
 * @file Core1IntegrationTest.h
 * @brief Core1 delegációs rendszer integritás teszt függvények
 *
 * Ez a fájl tartalmazza a Core1 FFT delegációs rendszer
 * átfogó tesztelésére szolgáló függvényeket.
 */

/**
 * @brief Átfogó integritás teszt a Core1 delegációs rendszerhez
 *
 * Ez a teszt ellenőrzi hogy:
 * - Core1FftProcessor megfelelően működik
 * - AudioProcessorCore1Integration működik különböző módokban
 * - Aszinkron feldolgozás működik
 * - Hibatűrés és visszaesés mechanizmusok működnek
 * - Memória használat megfelelő
 */
void runCore1IntegrationTest();

/**
 * @brief Gyors funkcionális teszt a kritikus funkciókhoz
 *
 * Minimális teszt ami gyorsan ellenőrzi hogy a
 * Core1 delegációs rendszer alapfunkciói működnek.
 */
void runQuickCore1Test();
