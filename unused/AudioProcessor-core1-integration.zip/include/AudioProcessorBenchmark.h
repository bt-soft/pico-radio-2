#ifndef AUDIO_PROCESSOR_BENCHMARK_H
#define AUDIO_PROCESSOR_BENCHMARK_H

#include <Arduino.h>

#include <string>
#include <vector>

/**
 * @brief AudioProcessor teljesítménybenchmark osztály Core1 delegálhatóság értékeléséhez
 *
 * Ez az osztály részletes teljesítményméréseket végez az AudioProcessor-on különböző
 * FFT méretekkel, hogy értékelje a Core1-re való delegálás megvalósíthatóságát.
 */
class AudioProcessorBenchmark {
   public:
    /**
     * @brief Egyetlen benchmark futtatás eredménye
     */
    struct BenchmarkResult {
        uint16_t fftSize;                   ///< Tesztelt FFT méret
        int iterations;                     ///< Iterációk száma
        uint64_t averageProcessTimeMicros;  ///< Átlagos feldolgozási idő mikroszekundumban
        uint64_t minProcessTimeMicros;      ///< Minimális feldolgozási idő
        uint64_t maxProcessTimeMicros;      ///< Maximális feldolgozási idő
        uint32_t memoryUsageBytes;          ///< Memóriahasználat byte-ban
        float estimatedCpuUsagePercent;     ///< Becsült CPU használat százalékban
        bool success;                       ///< Sikeres volt-e a mérés

        BenchmarkResult()
            : fftSize(0),
              iterations(0),
              averageProcessTimeMicros(0),
              minProcessTimeMicros(0),
              maxProcessTimeMicros(0),
              memoryUsageBytes(0),
              estimatedCpuUsagePercent(0.0f),
              success(false) {}
    };

    /**
     * @brief Teljes benchmark sorozat eredményei
     */
    struct FullBenchmarkResults {
        std::vector<BenchmarkResult> results;  ///< Egyedi mérési eredmények
        BenchmarkResult bestPerformance;       ///< Legjobb teljesítmény
        BenchmarkResult worstPerformance;      ///< Legrosszabb teljesítmény
        uint64_t averageProcessTime;           ///< Átlagos feldolgozási idő az összes FFT méretre
        uint32_t totalMemoryUsage;             ///< Összes memóriahasználat
        float averageCpuUsage;                 ///< Átlagos CPU használat

        FullBenchmarkResults() : averageProcessTime(0), totalMemoryUsage(0), averageCpuUsage(0.0f) {}
    };

    /**
     * @brief Core1 delegálhatóság elemzési eredményei
     */
    struct Core1DelegationAnalysis {
        bool isRecommended;                    ///< Ajánlott-e a Core1 delegálás
        uint16_t recommendedFftSize;           ///< Javasolt FFT méret
        float estimatedCore1CpuUsage;          ///< Becsült Core1 CPU használat (%)
        uint32_t estimatedMemoryOverhead;      ///< Becsült memória overhead
        uint64_t estimatedFifoOverheadMicros;  ///< Becsült FIFO kommunikációs overhead (us)
        uint64_t estimatedSyncOverheadMicros;  ///< Becsült szinkronizációs overhead (us)
        std::vector<std::string> reasons;      ///< Részletes indokok és magyarázatok

        Core1DelegationAnalysis()
            : isRecommended(false),
              recommendedFftSize(0),
              estimatedCore1CpuUsage(0.0f),
              estimatedMemoryOverhead(0),
              estimatedFifoOverheadMicros(0),
              estimatedSyncOverheadMicros(0) {}
    };

    /**
     * @brief Konstruktor
     */
    AudioProcessorBenchmark();

    /**
     * @brief Destruktor
     */
    ~AudioProcessorBenchmark();

    /**
     * @brief Egyetlen FFT méret teljesítménytesztje
     * @param fftSize FFT méret
     * @param iterations Iterációk száma az átlagoláshoz
     * @return BenchmarkResult struktúra az eredményekkel
     */
    BenchmarkResult benchmarkProcessFunction(uint16_t fftSize, int iterations = 10);

    /**
     * @brief Teljes benchmark sorozat futtatása különböző FFT méretekkel
     * @return FullBenchmarkResults az összes eredménnyel
     */
    FullBenchmarkResults runFullBenchmark();

    /**
     * @brief Core1 delegálhatóság értékelése benchmark eredmények alapján
     * @param benchmarkResults A benchmark eredmények
     * @return Core1DelegationAnalysis az elemzési eredményekkel
     */
    Core1DelegationAnalysis analyzeCore1Delegation(const FullBenchmarkResults& benchmarkResults);

    /**
     * @brief Benchmark eredmények részletes kiírása
     * @param results A kiírandó eredmények
     */
    void printDetailedResults(const FullBenchmarkResults& results);

    /**
     * @brief Core1 elemzési eredmények kiírása
     * @param analysis Az elemzési eredmények
     */
    void printCore1Analysis(const Core1DelegationAnalysis& analysis);

   private:
    uint32_t lastMemoryUsage;  ///< Utolsó memóriahasználat mérés referenciához
};

#endif  // AUDIO_PROCESSOR_BENCHMARK_H
