#ifndef AUDIO_PROCESSOR_CORE1_ANALYSIS_H
#define AUDIO_PROCESSOR_CORE1_ANALYSIS_H

#include "AudioProcessorBenchmark.h"
#include "Core1AudioDelegation.h"
#include "defines.h"

/**
 * @brief Comprehensive analysis system for AudioProcessor Core1 delegation feasibility
 *
 * This class provides integrated analysis capabilities to evaluate whether
 * AudioProcessor operations can be effectively delegated to Core1, including
 * performance benchmarking, memory analysis, and communication overhead assessment.
 */
class AudioProcessorCore1Analysis {
   public:
    /**
     * @brief Results of the comprehensive Core1 delegation analysis
     */
    struct AnalysisResults {
        // Benchmark results
        AudioProcessorBenchmark::FullBenchmarkResults benchmarkResults;

        // Communication analysis
        uint32_t estimatedCommOverhead;  // microseconds per process call
        uint32_t fifoBufferRequirement;  // bytes needed for FIFO
        float commEfficiencyRatio;       // processing_time / (processing_time + comm_overhead)

        // Memory analysis
        uint32_t core0MemorySavings;      // bytes freed on Core0
        uint32_t core1MemoryRequirement;  // bytes needed on Core1
        bool memoryFeasible;              // whether memory constraints allow delegation

        // Performance analysis
        float expectedSpeedup;      // expected performance improvement ratio
        float cpuUtilizationCore0;  // estimated Core0 CPU usage after delegation
        float cpuUtilizationCore1;  // estimated Core1 CPU usage with audio processing

        // Final recommendation
        bool recommendDelegation;      // overall recommendation
        const char* reasoningSummary;  // textual explanation of decision

        // Implementation guidance
        const char* implementationNotes;  // specific implementation recommendations
        const char* riskAssessment;       // potential risks and mitigation strategies
    };

    /**
     * @brief Configuration for the analysis process
     */
    struct AnalysisConfig {
        bool includeDetailedBenchmark;  // whether to run full benchmark suite
        bool measureCommOverhead;       // whether to measure communication costs
        uint16_t testIterations;        // number of iterations for timing tests
        uint16_t maxFftSize;            // maximum FFT size to test
        bool verboseOutput;             // whether to print detailed progress

        AnalysisConfig() : includeDetailedBenchmark(true), measureCommOverhead(true), testIterations(10), maxFftSize(2048), verboseOutput(true) {}
    };

    /**
     * @brief Constructor
     */
    AudioProcessorCore1Analysis();

    /**
     * @brief Destructor
     */
    ~AudioProcessorCore1Analysis();

    /**
     * @brief Perform comprehensive analysis of Core1 delegation feasibility
     *
     * @param config Analysis configuration parameters
     * @return Complete analysis results with recommendation
     */
    AnalysisResults performFullAnalysis(const AnalysisConfig& config = AnalysisConfig());

    /**
     * @brief Quick feasibility check without full benchmarking
     *
     * @param fftSize FFT size to test
     * @return Basic feasibility assessment
     */
    bool quickFeasibilityCheck(uint16_t fftSize = 512);

    /**
     * @brief Estimate communication overhead for given data size
     *
     * @param dataSize Size of data to transfer (bytes)
     * @return Estimated overhead in microseconds
     */
    uint32_t estimateCommunicationOverhead(uint32_t dataSize);

    /**
     * @brief Print detailed analysis report
     *
     * @param results Analysis results to print
     */
    void printAnalysisReport(const AnalysisResults& results);

   private:
    AudioProcessorBenchmark* benchmark;
    Core1AudioDelegation* delegation;

    // Internal analysis methods
    uint32_t measureFifoTransferTime(uint32_t dataSize, uint16_t iterations = 50);
    uint32_t calculateMemoryRequirements(uint16_t fftSize);
    float estimatePerformanceGain(const AudioProcessorBenchmark::FullBenchmarkResults& benchResults);
    bool assessMemoryFeasibility(uint32_t core1Requirement);
    const char* generateRecommendationReasoning(const AnalysisResults& results);
    const char* generateImplementationNotes(const AnalysisResults& results);
    const char* generateRiskAssessment(const AnalysisResults& results);

    // Analysis state
    bool initialized;
    uint32_t lastAnalysisTimestamp;
};

#endif  // AUDIO_PROCESSOR_CORE1_ANALYSIS_H
