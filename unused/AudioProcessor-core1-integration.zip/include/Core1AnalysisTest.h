#pragma once

/**
 * @file Core1AnalysisTest.h
 * @brief Test functions for AudioProcessor Core1 delegation analysis
 *
 * This file contains test functions to evaluate the feasibility and performance
 * characteristics of delegating AudioProcessor operations to Core1 on the RP2040.
 */

/**
 * @brief Comprehensive test for Core1 delegation analysis
 *
 * Runs a full battery of tests including:
 * - Quick feasibility checks for multiple FFT sizes
 * - Detailed performance benchmarking
 * - Memory usage analysis
 * - Communication overhead assessment
 * - Final recommendations and risk assessment
 *
 * This test produces detailed debug output showing all analysis results
 * and recommendations for whether Core1 delegation should be implemented.
 */
void runCore1DelegationAnalysisTest();

/**
 * @brief Quick feasibility test for current system configuration
 *
 * Performs a rapid assessment of whether Core1 delegation is feasible
 * for the current FFT size. This is suitable for periodic checks or
 * system diagnostics without the overhead of a full analysis.
 *
 * Results are logged to debug output with simple pass/fail indication.
 */
void runQuickCore1FeasibilityTest();
