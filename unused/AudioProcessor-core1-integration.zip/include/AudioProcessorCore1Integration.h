#pragma once

#include <stdint.h>

#include <functional>

#include "AudioProcessor.h"
#include "Core1AsyncTaskManager.h"
#include "Core1FftProcessor.h"
#include "defines.h"

/**
 * @brief AudioProcessor Core1 integráció kezelő
 *
 * Ez az osztály kezeli a meglévő AudioProcessor és az új Core1-based
 * FFT feldolgozás közötti integrációt. Átlátszó módon válthat a Core0
 * és Core1 feldolgozás között.
 */
class AudioProcessorCore1Integration {
   public:
    /**
     * @brief Feldolgozási mód típusok
     */
    enum class ProcessingMode : uint8_t {
        CORE0_ONLY = 0,    // Csak Core0 feldolgozás (eredeti)
        CORE1_ONLY = 1,    // Csak Core1 feldolgozás
        HYBRID = 2,        // Automatikus váltás terhelés alapján
        AUTO_FAILOVER = 3  // Core1 elsődleges, Core0 tartalék
    };

    /**
     * @brief Integráció konfigurációja
     */
    struct IntegrationConfig {
        ProcessingMode mode;
        bool enableAutoFallback;           // Automatikus visszaváltás Core0-ra hiba esetén
        uint32_t core1TimeoutMs;           // Core1 timeout
        uint32_t fallbackThresholdMs;      // Visszaváltási küszöb
        uint16_t hybridLoadThreshold;      // Hibrid mód terhelési küszöbe (%)
        bool enablePerformanceMonitoring;  // Teljesítmény monitorozás
        bool enableDetailedLogging;        // Részletes naplózás
    };

    /**
     * @brief Integráció állapot és statisztikák
     */
    struct IntegrationStats {
        ProcessingMode currentMode;
        bool core1Available;
        bool core0Active;
        uint32_t totalFFTProcessed;
        uint32_t core0FFTCount;
        uint32_t core1FFTCount;
        uint32_t core1Failures;
        uint32_t fallbackEvents;
        float core1SuccessRate;
        float averageCore0TimeMs;
        float averageCore1TimeMs;
        float performanceGain;  // Core1 vs Core0 teljesítménynyereség
        uint32_t lastSwitchTimestamp;
        bool isOptimal;  // Optimális módban fut-e
    };

   private:
    // Komponensek
    Core1FftProcessor* core1Processor_;
    Core1AsyncTaskManager* taskManager_;
    AudioProcessor* audioProcessor_;  // Referencia az eredeti AudioProcessor-ra

    // Konfiguráció és állapot
    IntegrationConfig config_;
    IntegrationStats stats_;
    bool initialized_;
    bool enabled_;

    // Teljesítmény monitorozás
    uint32_t lastPerformanceCheck_;
    std::vector<uint32_t> core0Times_;
    std::vector<uint32_t> core1Times_;
    static constexpr size_t PERF_HISTORY_SIZE = 10;

    // Fallback kezelés
    uint32_t lastCore1Failure_;
    uint32_t consecutiveFailures_;
    static constexpr uint32_t MAX_CONSECUTIVE_FAILURES = 3;
    static constexpr uint32_t FALLBACK_COOLDOWN_MS = 5000;

   public:
    /**
     * @brief Konstruktor
     * @param audioProcessor Eredeti AudioProcessor referencia
     */
    explicit AudioProcessorCore1Integration(AudioProcessor* audioProcessor);

    /**
     * @brief Destruktor
     */
    ~AudioProcessorCore1Integration();

    /**
     * @brief Integráció inicializálása
     * @param config Konfiguráció struktúra
     * @return true ha sikeres
     */
    bool initialize(const IntegrationConfig& config);

    /**
     * @brief Integráció leállítása
     */
    void shutdown();

    /**
     * @brief FFT feldolgozás (integrált interfész)
     * @param inputData Bemeneti audio minták
     * @param fftSize FFT méret
     * @param outputBuffer Kimeneti spektrum adatok
     * @param forceCore0 Core0 kényszerítése (opcionális)
     * @return true ha sikeres
     */
    bool processFFT(const float* inputData, uint16_t fftSize, float* outputBuffer, bool forceCore0 = false);

    /**
     * @brief Aszinkron FFT feldolgozás
     * @param inputData Bemeneti audio minták
     * @param fftSize FFT méret
     * @param outputBuffer Kimeneti spektrum adatok
     * @param callback Befejezési callback (opcionális)
     * @return Feladat ID vagy 0 ha hiba
     */
    uint32_t processFFTAsync(const float* inputData, uint16_t fftSize, float* outputBuffer, std::function<void(bool success, uint32_t processingTimeMs)> callback = nullptr);

    /**
     * @brief AudioProcessor kompatibilis feldolgozás (wrapper metódus)
     * Ez a metódus meghívja az eredeti AudioProcessor process() metódusát a Core1 integráción keresztül
     * @param collectOsciSamples Oszcilloszkóp minták gyűjtése
     */
    void process(bool collectOsciSamples);

    /**
     * @brief Feldolgozási mód váltása
     * @param mode Új feldolgozási mód
     * @return true ha sikeres
     */
    bool switchProcessingMode(ProcessingMode mode);

    /**
     * @brief Automatikus optimalizálás futtatása
     * Ez elemzi a teljesítményt és optimalizálja a beállításokat
     */
    void optimizePerformance();

    /**
     * @brief Integráció frissítése (fő loop-ból hívandó)
     */
    void update();

    /**
     * @brief Állapot és statisztikák lekérése
     * @return Statisztikák struktúra
     */
    IntegrationStats getStats() const;

    /**
     * @brief Jelenlegi feldolgozási mód lekérése
     * @return Aktív feldolgozási mód
     */
    ProcessingMode getCurrentMode() const { return config_.mode; }

    /**
     * @brief Core1 elérhetőségének ellenőrzése
     * @return true ha Core1 elérhető és működik
     */
    bool isCore1Available() const;

    /**
     * @brief Integráció állapotának ellenőrzése
     * @return true ha inicializálva és működik
     */
    bool isEnabled() const { return enabled_; }

    /**
     * @brief Teljesítmény jelentés generálása
     * @param detailed Részletes jelentés kérése
     */
    void printPerformanceReport(bool detailed = false) const;

    /**
     * @brief Konfiguráció módosítása futás közben
     * @param config Új konfiguráció
     * @return true ha sikeres
     */
    bool updateConfig(const IntegrationConfig& config);

    /**
     * @brief Core1 ping teszt végrehajtása
     * @return true ha Core1 válaszol
     */
    bool pingCore1() const;

    /**
     * @brief Automatikus fallback engedélyezése/tiltása
     * @param enable Engedélyezés állapota
     */
    void setAutoFallback(bool enable) { config_.enableAutoFallback = enable; }

   private:
    /**
     * @brief Core0 FFT feldolgozás (eredeti módszer)
     * @param inputData Bemeneti adatok
     * @param fftSize FFT méret
     * @param outputBuffer Kimeneti buffer
     * @return Feldolgozási idő mikroszekundumban
     */
    uint32_t processFFTCore0(const float* inputData, uint16_t fftSize, float* outputBuffer);

    /**
     * @brief Core1 FFT feldolgozás
     * @param inputData Bemeneti adatok
     * @param fftSize FFT méret
     * @param outputBuffer Kimeneti buffer
     * @return Feldolgozási idő mikroszekundumban, 0 ha hiba
     */
    uint32_t processFFTCore1(const float* inputData, uint16_t fftSize, float* outputBuffer);

    /**
     * @brief Optimális core kiválasztása
     * @param fftSize FFT méret
     * @return Ajánlott core (true = Core1, false = Core0)
     */
    bool selectOptimalCore(uint16_t fftSize);

    /**
     * @brief Hibrid mód terhelés ellenőrzése
     * @return true ha Core1-et kell használni
     */
    bool shouldUseCore1ForHybrid();

    /**
     * @brief Fallback kezelés Core1 hiba esetén
     * @param reason Hiba oka
     */
    void handleCore1Failure(const char* reason);

    /**
     * @brief Teljesítmény adatok frissítése
     * @param isCore1 Core1 volt-e használva
     * @param processingTimeMs Feldolgozási idő
     */
    void updatePerformanceData(bool isCore1, uint32_t processingTimeMs);

    /**
     * @brief Teljesítmény trend elemzése
     * @return true ha Core1 jobb teljesítményt nyújt
     */
    bool analyzePerformanceTrend();

    /**
     * @brief Automatikus mód váltás logika
     */
    void handleAutoModeSwitch();

    /**
     * @brief Statisztikák frissítése
     * @param isCore1 Core1 volt-e használva
     * @param success Sikeres volt-e
     * @param processingTimeMs Feldolgozási idő
     */
    void updateStats(bool isCore1, bool success, uint32_t processingTimeMs);

    /**
     * @brief Alapértelmezett konfiguráció betöltése
     */
    IntegrationConfig getDefaultConfig();

    /**
     * @brief Konfiguráció validálása
     * @param config Ellenőrizendő konfiguráció
     * @return true ha érvényes
     */
    bool validateConfig(const IntegrationConfig& config);

    /**
     * @brief Teljesítmény history inicializálása
     */
    void initializePerformanceHistory();
};
