#ifndef CORE1_AUDIO_DELEGATION_H
#define CORE1_AUDIO_DELEGATION_H

#include <Arduino.h>
#include <pico/multicore.h>
#include "AudioProcessor.h"
#include "core_communication.h"

/**
 * @brief Core1 AudioProcessor delegálás koordináló osztály
 * 
 * Ez az osztály kezeli az AudioProcessor működésének Core1-re történő delegálását,
 * beleértve a kommunikációt, szinkronizációt és adatátvitelt a Core0 és Core1 között.
 */

/**
 * @brief Kiterjesztett parancsok az AudioProcessor Core1 delegálásához
 */
enum AudioProcessorCore1Command : uint32_t {
    // Alapvető AudioProcessor parancsok
    CORE1_AUDIO_CMD_INIT = 0x100,           ///< AudioProcessor inicializálása Core1-en
    CORE1_AUDIO_CMD_SHUTDOWN = 0x101,       ///< AudioProcessor leállítása Core1-en
    CORE1_AUDIO_CMD_PROCESS = 0x102,        ///< Audio feldolgozás végrehajtása
    CORE1_AUDIO_CMD_SET_FFT_SIZE = 0x103,   ///< FFT méret beállítása
    CORE1_AUDIO_CMD_SET_GAIN = 0x104,       ///< Gain érték beállítása
    CORE1_AUDIO_CMD_GET_STATUS = 0x105,     ///< Core1 állapot lekérdezése
    
    // Adatlekérdező parancsok
    CORE1_AUDIO_CMD_GET_MAGNITUDE_DATA = 0x110,    ///< FFT magnitúdó adatok lekérése
    CORE1_AUDIO_CMD_GET_OSCILLOSCOPE_DATA = 0x111, ///< Oszcilloszkóp adatok lekérése
    CORE1_AUDIO_CMD_GET_PERFORMANCE_STATS = 0x112, ///< Teljesítménystatisztikák lekérése
    
    // Konfigurációs parancsok
    CORE1_AUDIO_CMD_ENABLE_AUTO_GAIN = 0x120,      ///< Auto gain engedélyezése
    CORE1_AUDIO_CMD_DISABLE_AUTO_GAIN = 0x121,     ///< Auto gain letiltása
    CORE1_AUDIO_CMD_SET_SAMPLING_FREQ = 0x122,     ///< Mintavételezési frekvencia beállítása
};

/**
 * @brief AudioProcessor állapotok Core1-en
 */
enum class Core1AudioState {
    UNINITIALIZED,    ///< Nincs inicializálva
    READY,           ///< Készen áll a parancsokra
    PROCESSING,      ///< Audio feldolgozás folyamatban
    ERROR,           ///< Hiba állapot
    SHUTDOWN         ///< Leállítva
};

/**
 * @brief Kommunikációs struktúra Core0-Core1 között
 */
struct Core1AudioMessage {
    uint32_t command;           ///< Parancs kód
    uint32_t param1;           ///< Első paraméter
    uint32_t param2;           ///< Második paraméter
    uint32_t param3;           ///< Harmadik paraméter
    uint32_t timestamp;        ///< Időbélyeg
    
    Core1AudioMessage() : command(0), param1(0), param2(0), param3(0), timestamp(0) {}
    Core1AudioMessage(uint32_t cmd, uint32_t p1 = 0, uint32_t p2 = 0, uint32_t p3 = 0) 
        : command(cmd), param1(p1), param2(p2), param3(p3), timestamp(millis()) {}
};

/**
 * @brief Teljesítménystatisztikák Core1 AudioProcessor-hez
 */
struct Core1AudioPerformanceStats {
    uint64_t totalProcessCalls;        ///< Összes process() hívás
    uint64_t averageProcessTimeMicros; ///< Átlagos feldolgozási idő
    uint64_t maxProcessTimeMicros;     ///< Maximális feldolgozási idő
    uint64_t minProcessTimeMicros;     ///< Minimális feldolgozási idő
    uint32_t memoryUsageBytes;         ///< Jelenlegi memóriahasználat
    float currentCpuUsagePercent;      ///< Jelenlegi CPU használat
    uint32_t errorCount;               ///< Hibák száma
    uint32_t lastUpdateTimestamp;      ///< Utolsó frissítés időbélyege
    
    Core1AudioPerformanceStats() : totalProcessCalls(0), averageProcessTimeMicros(0), 
                                  maxProcessTimeMicros(0), minProcessTimeMicros(UINT64_MAX),
                                  memoryUsageBytes(0), currentCpuUsagePercent(0.0f), 
                                  errorCount(0), lastUpdateTimestamp(0) {}
};

/**
 * @brief Core1 AudioProcessor delegálás manager osztály
 */
class Core1AudioDelegation {
public:
    /**
     * @brief Konstruktor
     */
    Core1AudioDelegation();
    
    /**
     * @brief Destruktor
     */
    ~Core1AudioDelegation();
    
    /**
     * @brief Core1 AudioProcessor delegálás inicializálása
     * @param fftSize Kezdeti FFT méret
     * @param gainValue Kezdeti gain érték
     * @param samplingFreq Mintavételezési frekvencia
     * @return true ha sikeres, false ha hiba
     */
    bool initializeCore1Audio(uint16_t fftSize = 256, float gainValue = 1.0f, double samplingFreq = 30000.0);
    
    /**
     * @brief Core1 AudioProcessor leállítása
     * @return true ha sikeres, false ha hiba
     */
    bool shutdownCore1Audio();
    
    /**
     * @brief Audio feldolgozás trigger Core1-en
     * @param collectOsciSamples Oszcilloszkóp mintagyűjtés engedélyezése
     * @return true ha sikeres, false ha hiba
     */
    bool triggerAudioProcess(bool collectOsciSamples = false);
    
    /**
     * @brief FFT méret beállítása Core1-en
     * @param newFftSize Új FFT méret
     * @return true ha sikeres, false ha hiba
     */
    bool setFftSize(uint16_t newFftSize);
    
    /**
     * @brief Gain érték beállítása Core1-en
     * @param gainValue Új gain érték
     * @return true ha sikeres, false ha hiba
     */
    bool setGainValue(float gainValue);
    
    /**
     * @brief Magnitúdó adatok lekérése Core1-ről
     * @param buffer Cél buffer a magnitúdó adatok számára
     * @param bufferSize Buffer mérete
     * @return Másolt adatok száma, 0 ha hiba
     */
    uint16_t getMagnitudeData(double* buffer, uint16_t bufferSize);
    
    /**
     * @brief Oszcilloszkóp adatok lekérése Core1-ről
     * @param buffer Cél buffer az oszcilloszkóp adatok számára
     * @param bufferSize Buffer mérete
     * @return Másolt adatok száma, 0 ha hiba
     */
    uint16_t getOscilloscopeData(int* buffer, uint16_t bufferSize);
    
    /**
     * @brief Core1 AudioProcessor állapot lekérdezése
     * @return Core1AudioState állapot
     */
    Core1AudioState getCore1AudioState();
    
    /**
     * @brief Teljesítménystatisztikák lekérése Core1-ről
     * @return Core1AudioPerformanceStats struktúra
     */
    Core1AudioPerformanceStats getPerformanceStats();
    
    /**
     * @brief Core1 AudioProcessor állapot ellenőrzése és hibajavítás
     * @return true ha minden rendben, false ha beavatkozás szükséges
     */
    bool checkAndMaintainCore1Audio();
    
    /**
     * @brief Kommunikációs timeout beállítása
     * @param timeoutMs Timeout milliszekundumban
     */
    void setCommandTimeout(uint32_t timeoutMs);
    
    /**
     * @brief Debug információk kiírása
     */
    void printDebugInfo();

private:
    Core1AudioState currentState_;              ///< Jelenlegi Core1 állapot
    uint32_t commandTimeoutMs_;                ///< Parancs timeout milliszekundumban
    uint32_t lastCommandTimestamp_;            ///< Utolsó parancs időbélyege
    Core1AudioPerformanceStats lastStats_;     ///< Utolsó teljesítménystatisztikák
    
    // Kommunikációs segédfüggvények
    bool sendCommandToCore1(const Core1AudioMessage& message, uint32_t timeoutMs = 0);
    bool waitForCore1Response(uint32_t timeoutMs = 0);
    bool sendSimpleCommand(AudioProcessorCore1Command cmd, uint32_t param1 = 0, uint32_t param2 = 0, uint32_t param3 = 0);
    
    // Adatátviteli segédfüggvények
    bool transferDataFromCore1(void* buffer, size_t bufferSize, size_t expectedDataSize);
    bool transferDataToCore1(const void* data, size_t dataSize);
    
    // Állapotkezelő segédfüggvények
    void updateState(Core1AudioState newState);
    bool isStateValid() const;
    void handleCommunicationError();
};

// Globális Core1 audio funkciódeklarációk (core1_audio_logic.cpp-ben implementálva)
extern "C" {
    /**
     * @brief Core1 audio logika fő belépési pontja
     */
    void core1_audio_main();
    
    /**
     * @brief Core1 AudioProcessor inicializálása
     * @param fftSize FFT méret
     * @param gainValue Gain érték
     * @param samplingFreq Mintavételezési frekvencia
     * @return 1 ha sikeres, 0 ha hiba
     */
    int core1_audio_initialize(uint16_t fftSize, uint32_t gainValueBits, uint32_t samplingFreqBits);
    
    /**
     * @brief Core1 AudioProcessor leállítása
     * @return 1 ha sikeres, 0 ha hiba
     */
    int core1_audio_shutdown();
    
    /**
     * @brief Audio feldolgozás végrehajtása Core1-en
     * @param collectOsciSamples Oszcilloszkóp mintagyűjtés flag
     * @return 1 ha sikeres, 0 ha hiba
     */
    int core1_audio_process(uint32_t collectOsciSamples);
    
    /**
     * @brief Core1 audio státusz lekérdezése
     * @return Core1AudioState értéke uint32_t-ként
     */
    uint32_t core1_audio_get_status();
}

#endif // CORE1_AUDIO_DELEGATION_H
