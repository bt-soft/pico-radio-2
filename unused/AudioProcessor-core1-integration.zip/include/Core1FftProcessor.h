#pragma once

#include <stdint.h>

#include <vector>

#include "defines.h"
#include "hardware/irq.h"
#include "pico/multicore.h"
#include "pico/mutex.h"

/**
 * @brief Core1 dedikált FFT feldolgozó osztály
 *
 * Ez az osztály kezeli az FFT számításokat a Core1-en, FIFO-alapú
 * kommunikációval a Core0-val. Célja a teljesítmény optimalizálás
 * a párhuzamos feldolgozás révén.
 */
class Core1FftProcessor {
   public:
    /**
     * @brief FFT feldolgozási parancs típusok
     */
    enum class CommandType : uint8_t { NONE = 0, PROCESS_FFT = 1, CHANGE_SIZE = 2, SHUTDOWN = 3, PING = 4 };

    /**
     * @brief FFT feldolgozási parancs struktúra
     */
    struct FftCommand {
        CommandType type;
        uint16_t fftSize;
        uint16_t dataLength;
        uint32_t timestamp;
        float* inputData;    // Pointer to input data
        float* outputData;   // Pointer to output buffer
        bool applyWindow;    // Apply windowing function
        uint8_t padding[3];  // Struktúra padding
    } __attribute__((packed));

    /**
     * @brief FFT feldolgozási eredmény struktúra
     */
    struct FftResult {
        CommandType originalCommand;
        uint16_t fftSize;
        uint16_t processedSamples;
        uint32_t processingTimeMicros;
        uint32_t timestamp;
        bool success;
        uint8_t errorCode;
        uint8_t padding[2];  // Struktúra padding
    } __attribute__((packed));

    /**
     * @brief Core1 feldolgozó statisztikák
     */
    struct ProcessorStats {
        uint32_t totalCommands;
        uint32_t successfulCommands;
        uint32_t failedCommands;
        uint32_t averageProcessingTimeMicros;
        uint32_t maxProcessingTimeMicros;
        uint32_t fifoOverflows;
        uint32_t fifoUnderruns;
        uint32_t lastCommandTimestamp;
        bool isRunning;
        uint8_t currentLoad;  // 0-100%
    };

   private:
    // FIFO konstansok
    static constexpr size_t COMMAND_FIFO_SIZE = 8;
    static constexpr size_t RESULT_FIFO_SIZE = 8;
    static constexpr size_t MAX_FFT_SIZE = 2048;
    static constexpr uint32_t COMMAND_TIMEOUT_MS = 1000;
    static constexpr uint32_t CORE1_STACK_SIZE = 8192;

    // Core1 állapot
    bool initialized_;
    bool core1Running_;
    bool shutdownRequested_;

    // FIFO pufferek
    static FftCommand commandFifo_[COMMAND_FIFO_SIZE];
    static FftResult resultFifo_[RESULT_FIFO_SIZE];
    static volatile size_t commandFifoHead_;
    static volatile size_t commandFifoTail_;
    static volatile size_t resultFifoHead_;
    static volatile size_t resultFifoTail_;

    // Szinkronizáció
    static mutex_t fifoMutex_;
    static volatile bool core1Initialized_;

    // Statisztikák
    static ProcessorStats stats_;

    // Memória pufferek Core1-en
    static float core1InputBuffer_[MAX_FFT_SIZE];
    static float core1OutputBuffer_[MAX_FFT_SIZE];
    static float core1WorkingBuffer_[MAX_FFT_SIZE];

   public:
    /**
     * @brief Konstruktor
     */
    Core1FftProcessor();

    /**
     * @brief Destruktor
     */
    ~Core1FftProcessor();

    /**
     * @brief Core1 inicializálása és FFT feldolgozó indítása
     * @return true ha sikeres, false ha hiba történt
     */
    bool initialize();

    /**
     * @brief Core1 leállítása és erőforrások felszabadítása
     */
    void shutdown();

    /**
     * @brief FFT feldolgozás indítása (aszinkron)
     * @param inputData Bemeneti audio minták
     * @param fftSize FFT méret (64-2048)
     * @param outputBuffer Kimeneti buffer a spektrum adatoknak
     * @param applyWindow Ablakfüggvény alkalmazása
     * @return true ha a parancs sikeresen elküldve, false egyébként
     */
    bool processFFTAsync(const float* inputData, uint16_t fftSize, float* outputBuffer, bool applyWindow = true);

    /**
     * @brief FFT feldolgozás eredményének lekérése
     * @param result Eredmény struktúra
     * @param timeoutMs Timeout milliszekundumban
     * @return true ha van eredmény, false ha timeout vagy hiba
     */
    bool getResult(FftResult& result, uint32_t timeoutMs = 100);

    /**
     * @brief Szinkron FFT feldolgozás (aszinkron + várakozás)
     * @param inputData Bemeneti audio minták
     * @param fftSize FFT méret
     * @param outputBuffer Kimeneti buffer
     * @param applyWindow Ablakfüggvény alkalmazása
     * @param timeoutMs Timeout milliszekundumban
     * @return true ha sikeres, false egyébként
     */
    bool processFFTSync(const float* inputData, uint16_t fftSize, float* outputBuffer, bool applyWindow = true, uint32_t timeoutMs = 500);

    /**
     * @brief Core1 állapot és statisztikák lekérése
     * @return Statisztikák struktúra
     */
    ProcessorStats getStats() const;

    /**
     * @brief FIFO állapot ellenőrzése
     * @return true ha FIFO-k rendben, false ha túlcsordulás van
     */
    bool checkFifoHealth() const;

    /**
     * @brief Core1 ping tesztelése
     * @param timeoutMs Timeout milliszekundumban
     * @return true ha Core1 válaszol, false egyébként
     */
    bool pingCore1(uint32_t timeoutMs = 200);

    /**
     * @brief FFT méret módosítása Core1-en
     * @param newSize Új FFT méret
     * @return true ha sikeres, false egyébként
     */
    bool changeFFTSize(uint16_t newSize);

    /**
     * @brief Core1 futásának ellenőrzése
     * @return true ha Core1 fut és válaszol
     */
    bool isCore1Running() const { return core1Running_; }

    /**
     * @brief Inicializálás állapotának ellenőrzése
     * @return true ha inicializálva
     */
    bool isInitialized() const { return initialized_; }

   private:
    /**
     * @brief Core1 fő loop függvény (statikus)
     */
    static void core1Main();

    /**
     * @brief FFT számítás végrehajtása Core1-en
     * @param command Feldolgozási parancs
     * @return Feldolgozás eredménye
     */
    static FftResult executeFFT(const FftCommand& command);

    /**
     * @brief Parancs küldése Core1-nek
     * @param command Parancs struktúra
     * @return true ha sikeresen elküldve
     */
    bool sendCommand(const FftCommand& command);

    /**
     * @brief Eredmény olvasása Core1-től
     * @param result Eredmény struktúra
     * @return true ha van eredmény
     */
    bool readResult(FftResult& result);

    /**
     * @brief FIFO túlcsordulás kezelése
     */
    static void handleFifoOverflow();

    /**
     * @brief Windowing függvény alkalmazása
     * @param data Adat buffer
     * @param size Buffer méret
     */
    static void applyHammingWindow(float* data, size_t size);

    /**
     * @brief Statisztikák frissítése
     * @param result Feldolgozás eredménye
     */
    static void updateStats(const FftResult& result);

    /**
     * @brief Memória inicializálása Core1-en
     */
    static void initializeCore1Memory();

    /**
     * @brief FIFO-k inicializálása
     */
    static void initializeFifos();
};
