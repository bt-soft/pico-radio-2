#include "GlobalRdsCache.h"

// Statikus member definíció
GlobalRdsCache* GlobalRdsCache::instance = nullptr;
