#ifndef GLOBAL_RDS_CACHE_H
#define GLOBAL_RDS_CACHE_H

#include <Arduino.h>

/**
 * @brief Singleton osztály az RDS adatok cache-elésére
 *
 * Ez az osztály egy globális cache-t biztosít az RDS állomásnevek tárolására,
 * hogy elkerüljük a duplikált lekérdezéseket az FM és Memory Display között.
 */
class GlobalRdsCache {
   private:
    static GlobalRdsCache* instance;

    String cachedStationName;
    uint32_t lastUpdateTime;
    static const uint32_t CACHE_TIMEOUT_MS = 10000;  // 10 másodperc timeout

    // Private konstruktor a singleton pattern miatt
    GlobalRdsCache() : lastUpdateTime(0) {}

   public:
    /**
     * @brief Singleton instance lekérése
     * @return GlobalRdsCache* A cache instance pointere
     */
    static GlobalRdsCache* getInstance() {
        if (instance == nullptr) {
            instance = new GlobalRdsCache();
        }
        return instance;
    }

    /**
     * @brief RDS állomásnév cache-be mentése
     * @param stationName Az állomásnév
     */
    void updateStationName(const String& stationName) {
        cachedStationName = stationName;
        lastUpdateTime = millis();
    }

    /**
     * @brief Cache-elt RDS állomásnév lekérése
     * @param stationName[out] A cache-elt állomásnév (ha érvényes)
     * @return true ha a cache érvényes, false ha lejárt vagy üres
     */
    bool getCachedStationName(String& stationName) {
        if (cachedStationName.isEmpty()) {
            return false;
        }

        uint32_t currentTime = millis();
        // Millis overflow kezelése
        uint32_t elapsed = (currentTime >= lastUpdateTime) ? (currentTime - lastUpdateTime) : (UINT32_MAX - lastUpdateTime + currentTime + 1);

        if (elapsed > CACHE_TIMEOUT_MS) {
            clearCache();
            return false;
        }

        stationName = cachedStationName;
        return true;
    }

    /**
     * @brief Cache törlése
     */
    void clearCache() {
        cachedStationName = "";
        lastUpdateTime = 0;
    }

    /**
     * @brief Ellenőrzi, hogy a cache érvényes-e
     * @return true ha érvényes, false egyébként
     */
    bool isValid() {
        String dummy;
        return getCachedStationName(dummy);
    }
};

#endif  // GLOBAL_RDS_CACHE_H
