#ifndef CORE1_LOGIC_H
#define CORE1_LOGIC_H

void core1_main();  // A Core1 belépési pontja

#endif  // CORE1_LOGIC_H
